#include "../headers/raylib/raylib.h"

#include "../headers/maze/maze_vec_multi_tile.cpp"
#include <iostream>

//#include <iostream>

int main(){

    
    
    //maze properties
    int iterations = 50, maze_width = 300, maze_height = 300, tile_width = 5, tile_height = 5;
    //rendering:
    Image maze1_img_temp;
    Texture maze1_tex;
    //file stuff:
    double maze_id = 1;
    std::string maze_export_name;
    //view:
    float image_pos_x = 0, image_pos_y = 0, cam_speed = 1000;
    float zoom = 1;
    
    maze maze1(maze_width, maze_height, tile_width, tile_height);

    maze1.load_tile_types("level_0.json");
    //maze1.debug_print_tile_types();
    //maze1.debug_print_tile_types();

    
    /*maze1.add_tile_type(
        "cross",
        {"cross"}, 
        1, 1,
        "assets/img/cross.png",
        1,
        {{"cross", 99},{"hallway", 1}},
        {true}, {true}, {true}, {true}); // 0

    maze1.add_tile_type(
        "hallway",
        {"hallway"}, 
        1, 1, "assets/img/hallway.png", 
        1,
        {{"cross", 1},{"hallway", 99}},
        {true}, {false}, {true}, {false}); // 1


    maze1.save_tile_types("new_type_set.json");
    //return 0;//*/ 
    //maze1.load_tile_types("new_type_set.json");
    //maze1.debug_print_tile_types();

    maze1.type_editor();
    maze1.debug_print_tile_types();
    //return 0;
    SetConfigFlags(FLAG_WINDOW_RESIZABLE);
    InitWindow(1000, 1000/*maze1.tile_map_width * maze1.tile_width, maze1.tile_map_height * maze1.tile_height*/,"maze");
    SetTargetFPS(60);
    

    //maze1.save_tile_types("tile_types_properties.json");
    std::cout << "Initialisation done.\n";

    while(!WindowShouldClose()) {
        // Get the current mouse position
        Vector2 mousePosition = GetMousePosition();

        // Update zoom
        float zoomIncrement = GetMouseWheelMove() * 0.1f * zoom;  // Scale zoom change proportionally to the current zoom level
        zoom += zoomIncrement;

        // Ensure zoom is within reasonable bounds
        if (zoom < 0.5f){

            zoom = 0.5f;


        } else if (zoom > 10.0f){

            zoom = 10.0f;


        } else {

                // Calculate the change in zoom
        float zoomChange = zoom / (zoom - zoomIncrement);

            // Adjust image position to keep the image centered around the mouse
            image_pos_x = mousePosition.x - (mousePosition.x - image_pos_x) * zoomChange;
            image_pos_y = mousePosition.y - (mousePosition.y - image_pos_y) * zoomChange;

        }

        // Handle keyboard input for moving the image
     // Use squared zoom for smooth movement

        if (IsKeyDown(KEY_A) || IsKeyDown(KEY_LEFT)) {
            image_pos_x += cam_speed * GetFrameTime();
        }
        if (IsKeyDown(KEY_D) || IsKeyDown(KEY_RIGHT)) {
            image_pos_x -= cam_speed * GetFrameTime();
        }
        if (IsKeyDown(KEY_W) || IsKeyDown(KEY_UP)) {
            image_pos_y += cam_speed * GetFrameTime();
        }
        if (IsKeyDown(KEY_S) || IsKeyDown(KEY_DOWN)) {
            image_pos_y -= cam_speed * GetFrameTime();
        }

        if (IsKeyPressed(KEY_E)) {
            maze_export_name = "maze_" + std::to_string(maze_id) + ".png";
            maze1.safe_maze(maze_export_name);
            maze_id++;
        }

        if (IsKeyPressed(KEY_ENTER) && IsKeyDown(KEY_LEFT_ALT)) {
            for (int iy = 0; iy < maze1.tile_map_height; iy++) {
                for (int ix = 0; ix < maze1.tile_map_width; ix++) {
                    maze1.tile_map[iy][ix].direction = 0;
                    maze1.tile_map[iy][ix].tile_type_id = -1;
                }
            }
            ImageClearBackground(&maze1.maze_img, MAGENTA);
            maze1.set_tile(10, 10, 0, 0);
            
            maze1.generate_maze_old(iterations);
            maze1.render_maze_debug();
            maze1_img_temp = ImageCopy(maze1.maze_img);
            maze1_tex = LoadTextureFromImage(maze1_img_temp);

        } else if (IsKeyPressed(KEY_ENTER)) {
            
            std::cout << "clearing map\n";
            maze1.clear_tile_map();
            std::cout << "clearing image\n";
            ImageClearBackground(&maze1.maze_img, BLACK);
            std::cout << "set starting tile\n";
            maze1.set_tile(10, 10, 0, 0);
            std::cout << "generating maze\n";
            maze1.generate_maze(iterations);
            std::cout << "rendering maze\n";
            maze1.render_maze();

            maze1_img_temp = ImageCopy(maze1.maze_img);
            maze1_tex = LoadTextureFromImage(maze1_img_temp);
            
        }

        BeginDrawing();

        ClearBackground(BLACK);

        // Adjust the position and zoom
        DrawTextureEx(maze1_tex, (Vector2){image_pos_x, image_pos_y}, 0.0f, zoom, WHITE);

        EndDrawing();
    }

        //UnloadTexture(maze1_tex);

}