compile with
g++ -o main source/main.cpp -Isource/headers -Lsource/headers/raylib -lraylib && ./main
or
clang++ -o main source/main.cpp -Isource/headers -Lsource/headers/raylib -lraylib && ./main (yes brilliant i know)
assets/img/backrooms_tile_set/single_tile/wide_1/