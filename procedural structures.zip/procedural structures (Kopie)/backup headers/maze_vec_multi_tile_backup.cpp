#include "../raylib/raylib.h"
#include <ios>
#include <json/value.h>
#include <ostream>
#include <string>
//#include <cstring>
//#include <utility>
#include <utility>
#include <vector>
#include <iostream>
//#include <random>
#include <ctime>
#include <json/json.h>
#include <fstream>
#include <algorithm>

void ImageDrawImage(Image &target_image, Image &current_image, int x, int y) {

    for(int i_y = 0; i_y < current_image.height; i_y++){

        for(int i_x = 0; i_x < current_image.width; i_x++){

            ImageDrawPixel(&target_image, i_x + x, i_y + y, GetImageColor(current_image, i_x, i_y));
        
        }

    }

}

struct propabillity_specifier{ // specifies that this tile type has increased neighbour spawn rates of specific other tile types. 

    std::string index;
    int propabillity;

};

struct tile_type{

    std::string type_name;
    
    int width, height;
    Image type_image;
    std::string image_path;
    float default_propabillity; // to spawn in %.
    std::vector<propabillity_specifier> propabillity_specifiers; // propabillity multiplier for specified neighbouring tile_types to spawn.
    std::vector<std::string> tags;
    std::vector<bool> north; 
    std::vector<bool> east;
    std::vector<bool> south;
    std::vector<bool> west;

    tile_type(std::string type_name_p, int width_p, int height_p, std::string image_path, float default_propabillity_p, std::vector<propabillity_specifier> propabillity_specifiers_p, std::vector<std::string> tags, std::vector<bool> north_p, std::vector<bool> east_p, std::vector<bool> south_p, std::vector<bool> west_p){

        this->type_name = type_name_p;
        this->width = width_p;
        this->height = height_p;
        this->type_image = LoadImage(image_path.c_str());
        this->image_path = image_path;
        this->default_propabillity = default_propabillity_p;
        this->propabillity_specifiers = propabillity_specifiers_p;
        this->tags = tags;

        this->north = north_p;
        this->east = east_p;
        this->south = south_p;
        this->west = west_p;

    }

    tile_type(){}

    int sum_propabillity_specific = 0;
    bool specified_propabillity = false;

    Json::Value get_json() {

        Json::Value json;
        json["type_name"] = type_name;
        json["width"] = width;
        json["height"] = height;
        json["type_image_path"] = image_path;
        json["default_propabillity"] = default_propabillity;

        for (int i = 0; i < propabillity_specifiers.size(); i++) {
            json["propabillity_specifiers"][i]["propabillity"] = propabillity_specifiers[i].propabillity;
            json["propabillity_specifiers"][i]["index"] = propabillity_specifiers[i].index;
        }

        for(int i = 0; i < tags.size(); i++) json["tags"].append(tags[i]);

        for (bool val : north) json["north"].append(val);

        for (bool val : east) json["east"].append(val);

        for (bool val : south) json["south"].append(val);

        for (bool val : west) json["west"].append(val);

        return json;
    }

    void load_from_json(Json::Value json) {

        type_name = json["type_name"].asString();
        width = json["width"].asInt();
        height = json["height"].asInt();
        type_image = LoadImage(json["type_image_path"].asCString());
        image_path = json["type_image_path"].asString(); 
        default_propabillity = json["default_propabillity"].asFloat();

        propabillity_specifiers.clear();
        for (int i = 0; i < json["propabillity_specifiers"].size(); i++) {
            propabillity_specifier specifier;
            specifier.propabillity = json["propabillity_specifiers"][i]["propabillity"].asInt();
            specifier.index = json["propabillity_specifiers"][i]["index"].asInt();
            propabillity_specifiers.push_back(specifier);
        }

        tags.clear();
        for(const auto& json_val : json["tags"]) tags.push_back(json_val.asString());

        north.clear();
        for (const auto& json_val : json["north"]) north.push_back(json_val.asBool());

        east.clear();
        for (const auto& json_val : json["east"]) east.push_back(json_val.asBool());

        south.clear();
        for (const auto& json_val : json["south"]) south.push_back(json_val.asBool());

        west.clear();
        for (const auto& json_val : json["west"]) west.push_back(json_val.asBool());
    }
    
};

struct tile{

    int tile_type_id = -1;
    int direction = 0;
    int tile_fraction_x = 0, tile_fraction_y = 0;

};



class maze{

public:
    int tile_map_width, tile_map_height, tile_width, tile_height;

    int sum_propabillity_default = 0;

    std::vector<tile_type> tile_types;
    std::vector<std::vector<tile>> tile_map;

    Image maze_img;
    

    maze(int tile_map_width_p, int tile_map_height_p, int tile_width_p, int tile_height_p){
        tile_map.resize(tile_map_width_p, std::vector<tile>(tile_map_height_p));

        tile_map_width = tile_map_width_p;
        tile_map_height = tile_map_height_p;
        tile_width = tile_width_p;
        tile_height = tile_height_p;

        maze_img = GenImageColor(tile_map_width * tile_width, tile_map_height * tile_height, BLACK);

        srand(std::time(0));

    }
    //-------------------------------------------------------------------------------------------------------------
    //tile map modifications:
    
    //modifies the type of a tile at said position
    void r_type(Vector2 position_p, int tile_type_id_p){

        tile_map[position_p.y][position_p.x].tile_type_id = tile_type_id_p;

    }
    
    //modifies the direction of a tile at said position
    void set_tile_direction(Vector2 position_p, int direction_p){

        tile_map[position_p.y][position_p.x].direction = direction_p;

    }
    /*
    //rotates the tile left by changing its direction acordingly
    void rotate_tile_left(Vector2 position_p){

        if(tile_map[position_p.y][position_p.x].direction == 0){

            tile_map[position_p.y][position_p.x].direction = 3;

        } else if(tile_map[position_p.y][position_p.x].direction == 1){

            tile_map[position_p.y][position_p.x].direction = 0;

        } else if(tile_map[position_p.y][position_p.x].direction == 2){

            tile_map[position_p.y][position_p.x].direction = 1;

        } else {

            tile_map[position_p.y][position_p.x].direction = 2;

        }

    }
    
    //rotates the tile left by changing its direction acordingly
    void rotate_tile_right(Vector2 position_p){

        if(tile_map[position_p.y][position_p.x].direction == 0){

            tile_map[position_p.y][position_p.x].direction = 1;

        } else if(tile_map[position_p.y][position_p.x].direction == 1){

            tile_map[position_p.y][position_p.x].direction = 2;

        } else if(tivoid ImageDrawImage(Image &target_image, Image &current_image, int x, int y) {

    for(int i_y = 0; i_y < current_image.height; i_y++){

        for(int i_x = 0; i_x < current_image.width; i_x++){

            ImageDrawPixel(&target_image, i_x + x, i_y + y, GetImageColor(current_image, i_x, i_y));
        
        }

    }

}

            tile_map[position_p.y][position_p.x].direction = 0;

        }

    }*/

    //sets a specified tile onto the tilemap at said position

    //TODO: IGNORES HEIGHT AND WIDTH DIFFERENCES WHEN TILE IS ROTATED!!! WILL ONLY WORK FOR QUADRATIC TILES!

    void set_tile(int x, int y, int tile_type_id, int direction){

        static int width, height;

        width = tile_types[tile_type_id].width;
        height = tile_types[tile_type_id].height;
        
        if(direction % 2 != 0) std::swap(width,height);

        for(int i_y = 0; i_y < height; i_y++){

            for(int i_x = 0; i_x < width; i_x++){

                if(i_y + y < tile_map_height && i_x + x < tile_map_width){

                    //std::cout << "y:" << i_y + y << "|" << "x:" << i_x + x << "\n";
                
                    tile_map[y + i_y][x + i_x].tile_type_id = tile_type_id;
                    tile_map[y + i_y][x + i_x].direction = direction;
                    tile_map[y + i_y][x + i_x].tile_fraction_x = i_x;
                    tile_map[y + i_y][x + i_x].tile_fraction_y = i_y;

                }

            }

        }

    }

    //places a random tile applying specified randomness defined in each tiles type as far as such something exists
    void set_random_tile(int x, int y, int direction_p, int originating_type){
        static int sum_iterator;
        static int random_value;


        //std::cout << "originating type: " << originating_type << ", sum propabillity specific of given type: " << tile_types[originating_type].sum_propabillity_specific << ".\n";

        if(tile_types[originating_type].sum_propabillity_specific != 0){

            random_value = std::rand() % tile_types[originating_type].sum_propabillity_specific;

        } else {

            random_value = 1;

        }
        
        sum_iterator = 0;



        for(int i = 0; i < tile_types.size(); i++){

            //std::cout << i << "," << originating_type << "\n";
            sum_iterator += get_specified_propabillity(i, originating_type);

            if(sum_iterator > random_value){

                set_tile(x, y, i, direction_p);
                //std::cout << i << ":" << tile_types[originating_type].sum_propabillity_specific << "," << random_value << "," << sum_iterator << "\n";
                return;

            }

        }

    }

    int get_random_tile(int originating_type){
        static int sum_iterator;
        static int random_value;


        //std::cout << "originating type: " << originating_type << ", sum propabillity specific of given type: " << tile_types[originating_type].sum_propabillity_specific << ".\n";

        if(tile_types[originating_type].sum_propabillity_specific != 0){

            random_value = std::rand() % tile_types[originating_type].sum_propabillity_specific;

        } else {

            random_value = 1;

        }
        
        sum_iterator = 0;



        for(int i = 0; i < tile_types.size(); i++){

            //std::cout << i << "," << originating_type << "\n";
            sum_iterator += get_specified_propabillity(i, originating_type);

            if(sum_iterator > random_value){
                //std::cout << i << ":" << tile_types[originating_type].sum_propabillity_specific << "," << random_value << "," << sum_iterator << "\n";
                return i;

            }

        }

        return -1;

    }

    //returns a rendom type specificly for the type it currently appends from
    int get_random_type(int originating_type){
        static int sum_iterator;
        static int random_value;

        random_value = std::rand() % tile_types[originating_type].sum_propabillity_specific;
        sum_iterator = 0;

        if(originating_type > -1 && originating_type < tile_types.size()){

            for(int i = 0; i < tile_types.size(); i++){
            
                //std::cout << i << "," << originating_type << "\n";
                sum_iterator += get_specified_propabillity(i, originating_type);

                if(sum_iterator > random_value){

                    return i;
                    //std::cout << i << ":" << tile_types[originating_type].sum_propabillity_specific << "," << random_value << "," << sum_iterator << "\n";

                }

            }

        }

        return -1;

    }
    
    //resizes the height/width of heightmap(yes i know i am brilliant):
    void resize_tile_map(int width, int height){

        tile_map.resize(width, std::vector<tile>(height));

    }

    //-------------------------------------------------------------------------------------------------------------
    //tile map info:

    //checks if a absolute side of a tile considering its type and direction is open

    bool is_side_open(int side_direction, int tile_direction, int tile_type_id, int node){

        //side direction = absolute direction,
        //tile direction = rotation of the tile

        if(side_direction == 0){ // north

            if(tile_direction == 0){

                return tile_types[tile_type_id].north[node];
                
            } else if(tile_direction == 1){

                return tile_types[tile_type_id].west[node];
                
            } else if(tile_direction == 2){

                return tile_types[tile_type_id].south[node];
                
            } else {

                return tile_types[tile_type_id].east[node];

            }

        } else if(side_direction == 1){ // east

            if(tile_direction == 0){

                return tile_types[tile_type_id].east[node];
                
            } else if(tile_direction == 1){

                return tile_types[tile_type_id].north[node];
                
            } else if(tile_direction == 2){

                return tile_types[tile_type_id].west[node];
                
            } else {

                return tile_types[tile_type_id].south[node];

            }

        } else if(side_direction == 2){ // south
     
            if(tile_direction == 0){

                return tile_types[tile_type_id].south[node];
                
            } else if(tile_direction == 1){

                return tile_types[tile_type_id].east[node];
                
            } else if(tile_direction == 2){

                return tile_types[tile_type_id].north[node];
                
            } else {

                return tile_types[tile_type_id].west[node];

            }

        } else { // west

            if(tile_direction == 0){

                return tile_types[tile_type_id].west[node];
                
            } else if(tile_direction == 1){

                return tile_types[tile_type_id].south[node];
                
            } else if(tile_direction == 2){

                return tile_types[tile_type_id].east[node];
                
            } else {

                return tile_types[tile_type_id].north[node];

            }

        }

        return false;

    }

    bool is_empty(int pos_x, int pos_y, int width, int height) {
        
        for(int i_y = pos_y; i_y < pos_y + height; i_y++) {

            for(int i_x = pos_x; i_x < pos_x + width; i_x++) {


                if(tile_map[i_y][i_x].tile_type_id != -1 || i_x < 0 || i_y < 0 || i_x > tile_map_width || i_y > tile_map_height) {

                    return false;

                }

            }

        }

        return true;

    }
    
    //checks if two neighbouring tiles are open to each other

    /*!!!NOT MULTITILE TYPE COMPATIBLE YET
    bool is_connected(int tile_1_x, int tile_1_y, int direction){

        if(direction == 0 && tile_map[tile_1_y - 1][tile_1_x].tile_type_id != -1){

            if(is_side_open(direction, tile_map[tile_1_y][tile_1_x].direction, tile_types[tile_map[tile_1_y][tile_1_x].tile_type_id]) &&
               is_side_open((direction + 2) >= 4 ? (direction + 2) - 4 : (direction + 2), tile_map[tile_1_y - 1][tile_1_x].direction, tile_types[tile_map[tile_1_y - 1][tile_1_x].tile_type_id])){

                return true;

            } else return false;

        } else if(direction == 1 && tile_map[tile_1_y][tile_1_x + 1].tile_type_id != -1){

            if(is_side_open(direction, tile_map[tile_1_y][tile_1_x].direction, tile_types[tile_map[tile_1_y][tile_1_x].tile_type_id]) &&
               is_side_open((direction + 2) >= 4 ? (direction + 2) - 4 : (direction + 2), tile_map[tile_1_y][tile_1_x + 1].direction, tile_types[tile_map[tile_1_y][tile_1_x + 1].tile_type_id])){

                return true;

            } else return false;

        } else if(direction == 2 && tile_map[tile_1_y + 1][tile_1_x].tile_type_id != -1){

            if(is_side_open(direction, tile_map[tile_1_y][tile_1_x].direction, tile_types[tile_map[tile_1_y][tile_1_x].tile_type_id]) &&
               is_side_open((direction + 2) >= 4 ? (direction + 2) - 4 : (direction + 2), tile_map[tile_1_y + 1][tile_1_x].direction, tile_types[tile_map[tile_1_y + 1][tile_1_x].tile_type_id])){

                return true;

            } else return false;

        } else if(direction == 3 && tile_map[tile_1_y][tile_1_x - 1].tile_type_id != -1) {

            if(is_side_open(direction, tile_map[tile_1_y][tile_1_x].direction, tile_types[tile_map[tile_1_y][tile_1_x].tile_type_id]) &&
               is_side_open(direction + 2, tile_map[tile_1_y][tile_1_x - 1].direction, tile_types[tile_map[tile_1_y][tile_1_x - 1].tile_type_id])){

                return true;

            } else return false;

        }

        return false;

    }
    */
    //restores tilemap to default state removing all tile info
    
    void clear_tile_map(){

        for(int i_y = 0; i_y < tile_map_height;i_y++){

            for(int i_x = 0; i_x < tile_map_height;i_x++){

                tile_map[i_y][i_x].direction = 0;
                tile_map[i_y][i_x].tile_type_id = -1;
                tile_map[i_y][i_x].tile_fraction_x = 0;
                tile_map[i_y][i_x].tile_fraction_y = 0;
            
            }

        }

    }

    //generates the maze by modifying the tilemap
    /*void generate_maze(int iterations){

        for(int i = 0; i < iterations; i++){

            for(int i_y = 0; i_y < tile_map_height; i_y++){

                for(int i_x = 0; i_x < tile_map_width; i_x++){

                    if(tile_map[i_y][i_x].tile_type_id != -1){
                        
                        //north:
                        if(i_y - 1 >= 0 && tile_map[i_y - 1][i_x].tile_type_id == -1 && is_side_open(0, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id)){

                            set_random_tile(i_x, i_y - 1, 0, tile_map[i_y][i_x].tile_type_id);

                        }

                        //east:
                        if(i_x + 1 < tile_map_width && tile_map[i_y][i_x + 1].tile_type_id == -1 && is_side_open(1, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id)){

                            set_random_tile(i_x + 1, i_y, 1, tile_map[i_y][i_x].tile_type_id);
                            
                        }

                        //south:
                        if(i_y + 1 < tile_map_height && tile_map[i_y + 1][i_x].tile_type_id == -1 && is_side_open(2, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id)){

                            set_random_tile(i_x, i_y + 1, 2, tile_map[i_y][i_x].tile_type_id);

                        }
                        
                        //west:
                        if(i_x - 1 >= 0 && tile_map[i_y][i_x - 1].tile_type_id == -1 && is_side_open(3, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id)){

                            set_random_tile(i_x - 1, i_y, 3, tile_map[i_y][i_x].tile_type_id);
                            
                        }
                        
                    }

                }

            }

        }

    }*/
    
    void generate_maze_old(int iterations){
        
        static float percentage;
        percentage = 0;

        for(int i = 0; i < iterations; i++){
            

            percentage = (float)(i + 1) / iterations * 100;
            std::cout << "\rProgress: " << percentage << std::flush;
            for(int i_y = 0; i_y < tile_map_height; i_y++){

                for(int i_x = 0; i_x < tile_map_width; i_x++){
                
                    if(tile_map[i_y][i_x].tile_type_id != -1){
    
                        if(i_y - 1 > -1 && tile_map[i_y - 1][i_x].tile_type_id == -1 && is_side_open(0, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id, 0)){
                        
                            set_random_tile(i_x, i_y - 1, 0, tile_map[i_y][i_x].tile_type_id);
                            
                        }
    
                        if(i_x + 1 < tile_map_width && tile_map[i_y][i_x + 1].tile_type_id == -1 && is_side_open(1, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id, 0)){
                        
                            set_random_tile(i_x + 1, i_y, 1, tile_map[i_y][i_x].tile_type_id);
                            
                        }
                        
                        if(i_y + 1 < tile_map_height && tile_map[i_y + 1][i_x].tile_type_id == -1 && is_side_open(2, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id, 0)){
                        
                            set_random_tile(i_x, i_y + 1, 2, tile_map[i_y][i_x].tile_type_id);
                            
                        }
    
                        if(i_x - 1 > -1 && tile_map[i_y][i_x - 1].tile_type_id == -1 && is_side_open(3, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id, 0)){
                        
                            set_random_tile(i_x - 1, i_y, 3, tile_map[i_y][i_x].tile_type_id);
                            
                        }
                        //return;
    
                    }
    
                }
    
            }

        }

    }

    //New version. Supports multi tiled fields. Probably worse performance
    void generate_maze(int iterations){
        
        std::cout << "Generating";
        
        int random_tile_type_id;
        int random_free_node;

        for(int i = 0; i < iterations; i++){

            for(int i_y = 0; i_y < tile_map_height; i_y++){

                for(int i_x = 0; i_x < tile_map_width; i_x++){

                    if(tile_map[i_y][i_x].tile_type_id >= 0 && tile_map[i_y][i_x].tile_fraction_x == 0 && tile_map[i_y][i_x].tile_fraction_y == 0){

                        set_tile_neighbours(i_x, i_y);

                    }

                }

            }

        }

    }

    int get_random_free_node(std::vector<bool> &nodes){
        //assuming 010010
        //assuming seed 1
        static int random_node;
        static int available_nodes;
        static int checked_nodes;
        available_nodes = 0;
        checked_nodes = -1;

        for(int i = 0; i < nodes.size(); i++){
            if(nodes[i]) available_nodes++;
        }

        
        random_node = std::rand() % available_nodes;

        for(int i = 0; i < nodes.size(); i++){
            if(nodes[i]) checked_nodes++;
            if(random_node == checked_nodes){
                //std::cout << "returned random node: " << i << "\n\n";
                return i;

            }

        }
        std::cout << "ERROR: NO FREE NODE NIGGA\n";
        return -1;
    }

    void set_tile_neighbours(int x, int y) {

        tile_type current_type = tile_types[tile_map[y][x].tile_type_id];

        rotate_tile(&current_type, 0, tile_map[y][x].direction);

        int tile_type_id = get_random_tile(tile_map[y][x].tile_type_id);
        int node = get_random_free_node(tile_types[tile_type_id].south);
        tile_type type = tile_types[tile_type_id];
        

        //for north
        //std::cout << "selected tile: " << type.type_name << ", node: " << node << ", width: " << type.width << ", height: " << type.height << "\n";
        for(int i = 0; i < current_type.north.size(); i++){

            if(current_type.north[i] && get_area_empty(x + i - node, y - type.height, type.width, type.height)){   
                
                //std::cout << "side north is free\n";
                set_tile(x + i - node, y - type.height, tile_type_id, 0);

                tile_type_id = get_random_tile(tile_map[y][x].tile_type_id);
                node = get_random_free_node(tile_types[tile_type_id].south);
                type = tile_types[tile_type_id];


            }

        }
        
        //for east
        //std::cout << "selected tile: " << type.type_name << ", node: " << node << ", width: " << type.width << ", height: " << type.height << "\n";
        for(int i = 0; i < current_type.east.size(); i++){
            
            if(current_type.east[i] && get_area_empty(x + current_type.width, y + i - node, type.width, type.height)){

                //std::cout << "side east is free\n";
                rotate_tile(&type, 0, 1);

                set_tile(x + current_type.width, y + i - node, tile_type_id, 1);

                tile_type_id = get_random_tile(tile_map[y][x].tile_type_id);
                node = get_random_free_node(tile_types[tile_type_id].south);
                type = tile_types[tile_type_id];

            }

        }

        for(int i = 0; i < current_type.south.size(); i++){
            
            if(current_type.south[i] && get_area_empty(x + i - (type.width - node - 1), y + current_type.height, type.width, type.height)){

                //std::cout << "side east is free\n";
                rotate_tile(&type, 0, 2);

                set_tile(x + i - (type.width - node - 1), y + current_type.height, tile_type_id, 2);

                tile_type_id = get_random_tile(tile_map[y][x].tile_type_id);
                node = get_random_free_node(tile_types[tile_type_id].south);
                type = tile_types[tile_type_id];

            }

        }





        //for west
        //std::cout << "selected tile: " << type.type_name << ", node: " << node << ", width: " << type.width << ", height: " << type.height << "\n";
        for(int i = 0; i < current_type.west.size(); i++){

            if(current_type.west[i] && get_area_empty(x - type.width, y + i - (type.height - node - 1), type.width, type.height)){
                
                //std::cout << "side west is free\n";
                rotate_tile(&type, 0, 3);

                set_tile(x - type.width, y + i - (type.height - node - 1), tile_type_id, 3);

                tile_type_id = get_random_tile(tile_map[y][x].tile_type_id);
                node = get_random_free_node(tile_types[tile_type_id].south);
                type = tile_types[tile_type_id];

            }

        }

    }

    bool get_area_empty(int x, int y, int width, int height){
        //std::cout << "starting area check...\n";
        for(int i_y = y; i_y < y + height; i_y++){

            for(int i_x = x; i_x < x + width; i_x++){

                if (i_x >= tile_map.size() || i_y >= tile_map.size() || i_x < 0 || i_y < 0) return false;

                if(tile_map[i_y][i_x].tile_type_id != -1){
                    
                    
                    //std::cout << "Area not empty\n";
                    return false;

                }

            }

        }
        //std::cout << "Area empty\n";
        return true;

    }

    void rotate_tile(tile_type *type, int current_direction, int target_direction) {
        // Calculate the number of 90-degree rotations needed
        int rotation_count = (target_direction - current_direction + 4) % 4;

        for (int i = 0; i < rotation_count; ++i) {
            // Perform a 90-degree clockwise rotation
            std::reverse(type->east.begin(), type->east.end());
            std::reverse(type->west.begin(), type->west.end());

            std::vector<bool> temp = type->west;

            type->west = type->south;
            type->south = type->east;
            type->east = type->north;
            type->north = temp;

            // Swap width and height
            std::swap(type->width, type->height);

        }

    }

    //-------------------------------------------------------------------------------------------------------------
    //tile type info:

    // checks if the current object specifies the propabillity of the target object.
    bool is_specified(int target_object_index, int current_object_index){

        for(int i = 0; i < tile_types[current_object_index].propabillity_specifiers.size(); i++){

            if(tile_types[current_object_index].propabillity_specifiers[i].index == target_object_index){

                return true;

            }

        }

        return false;

    }

    //returns value of specified propabillity for an object at given target_index, from the specifier array of object at given current_index. 
    int get_specified_propabillity(int target_index, int current_index){

        for(int i = 0; i < tile_types[current_index].propabillity_specifiers.size(); i++){

            if(tile_types[current_index].propabillity_specifiers[i].index == target_index){

                return tile_types[current_index].propabillity_specifiers[i].propabillity;

            }
            
        }

        return tile_types[target_index].default_propabillity;

    }

    //returns id of tile type with said name
    int get_type_id(std::string type_name_p){

        for(int i = 0; i < tile_types.size(); i++){

            if(tile_types[i].type_name == type_name_p){

                return i;

            }

        }

        return -1;

    }

    //returns type of tile with said name 
    tile_type get_type(std::string type_name){

        for(int i = 0; i < tile_types.size(); i++){

            if(tile_types[i].type_name == type_name){

                return tile_types[i];

            }

        }
        std::cout << "Tile type of name \"" << type_name << "\" not found. womp womp.\n";
        return tile_type{"none", 0, 0, "could not find tile type", 0, {}, {}, {false}, {false}, {false}, {false}};

    }

    //-------------------------------------------------------------------------------------------------------------
    //tile type modifications:

    //adds a tile type and defines its specified propabillity according to the propabillity list.
    void add_tile_type(std::string type_name_p, int width_p, int height_p, std::string image_path, float propabillity_default_p, std::vector<propabillity_specifier> propabillities_p, std::vector<std::string> tags, std::vector<bool> north_p, std::vector<bool> east_p, std::vector<bool> south_p, std::vector<bool>west_p){

        sum_propabillity_default += propabillity_default_p; // sum of all default propabillity values
        tile_types.push_back({type_name_p, width_p, height_p, image_path, propabillity_default_p, propabillities_p, tags, north_p, east_p, south_p, west_p});

        //for all tile types,
        for(int i = 0; i < tile_types.size();i++){

            tile_types[i].sum_propabillity_specific = 0; //reset all sum_propabillity_specific values to zero, so they can be reconfigured.

            //and for each type relative to each other type
            for(int i_specific = 0; i_specific < tile_types.size(); i_specific++){

                tile_types[i].sum_propabillity_specific += get_specified_propabillity(i_specific, i); // set sum_propabillity_specific to be the sum of all specified propabillities for that type.

                

                /*if(is_specified(i_specific, i)){

                    tile_types[i].sum_propabillity_specific += get_specified_propabillity(i_specific, i);

                } else {

                    tile_types[i].sum_propabillity_specific += tile_types[i_specific].default_propabillity;

                }*/

            }

            //std::cout << "specific " << i << ":" << tile_types[i].sum_propabillity_specific << "\n";

        }

    }

    //*hold your breath* removes a tile type...(doesnt work right now as im too lazy to fix it)
    void remove_tile_type(std::string type_name_p){

        for(int i = 0; i < tile_types.size(); i++){

            if(tile_types[i].type_name == type_name_p){

                tile_types.erase(tile_types.begin() + i);

            }

        }

    }

    //-------------------------------------------------------------------------------------------------------------
    //tile image modifications:
    
    //LEGACY CODE. renders the maze to the maze.img var. Only supports single tiled fields 
    void render_maze(){

        Image temp;

        std::cout << "rendering...\n";

        for(int i_y = 0; i_y < tile_map_height; i_y++){

            for(int i_x = 0; i_x < tile_map_width; i_x++){

                if(tile_map[i_y][i_x].tile_type_id != -1 && tile_map[i_y][i_x].tile_fraction_x == 0 && tile_map[i_y][i_x].tile_fraction_y == 0){

                    temp = ImageCopy(tile_types[tile_map[i_y][i_x].tile_type_id].type_image);

                    if(tile_map[i_y][i_x].direction == 0){

                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    } else if(tile_map[i_y][i_x].direction == 1){

                        ImageRotateCW(&temp);
                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    } if(tile_map[i_y][i_x].direction == 2){

                        ImageRotateCW(&temp);
                        ImageRotateCW(&temp);
                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    }if(tile_map[i_y][i_x].direction == 3){

                        ImageRotateCCW(&temp);
                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    }

                }
            
            }

        }

    }

    //renders the maze to the maze.img yet with a lot of debug info
    void render_maze_debug(){

        Image temp;

        std::cout << "\ntypes:\n";

        for(int i = 0; i < tile_types.size(); i++){

            std::cout << tile_types[i].type_name << ",n:";
            std::cout << "north: ";
            for(int id = 0; id < tile_types[i].width; id++){

                std::cout << tile_types[i].north[id];

            }

            std::cout << "\n";

            std::cout << "east: ";
            for(int id = 0; id < tile_types[i].width; id++){

                std::cout << tile_types[i].east[id];

            }

            std::cout << "\n";

            std::cout << "south: ";
            for(int id = 0; id < tile_types[i].width; id++){

                std::cout << tile_types[i].south[id];

            }

            std::cout << "\n";

            std::cout << "west: ";
            for(int id = 0; id < tile_types[i].width; id++){

                std::cout << tile_types[i].west[id];

            }

            std::cout << "\n";

        }

        std::cout << "rendering...\n";

        std::cout << "__________________________________________________________________\n";

        for(int i_y = 0; i_y < tile_map_height; i_y++){

            for(int i_x = 0; i_x < tile_map_width; i_x++){

                if(tile_map[i_y][i_x].tile_type_id != -1){

                    /*std::cout << tile_map[i_y][i_x].tile_type_id << tile_map[i_y][i_x].direction
                    << ",n:" << is_side_open(0, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id)
                    << ",e:" << is_side_open(1, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id)
                    << ",s:" << is_side_open(2, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id)
                    << ",w:" << is_side_open(3, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id) << "\n";*/

                    temp = ImageCopy(tile_types[tile_map[i_y][i_x].tile_type_id].type_image);

                    if(i_y - 1 >= 0 && tile_map[i_y - 1][i_x].tile_type_id == -1 && is_side_open(0, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id, tile_map[i_y][i_x].tile_fraction_y)){

                        ImageDrawRectangle(&maze_img, i_x * tile_width + tile_width / 4, i_y * tile_height - tile_height / 2, tile_width / 2, tile_height / 2, BLUE);
                        
                        

                    }

                    if(i_x + 1 < tile_map_width && tile_map[i_y][i_x + 1].tile_type_id == -1 && is_side_open(1, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id, tile_map[i_y][i_x].tile_fraction_x)){

                        ImageDrawRectangle(&maze_img, i_x * tile_width + tile_width, i_y * tile_height + tile_height / 4, tile_width / 2, tile_height / 2, GREEN);
                        
                    }

                    if(i_y + 1 < tile_map_height && tile_map[i_y + 1][i_x].tile_type_id == -1 && is_side_open(2, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id, tile_map[i_y][i_x].tile_fraction_y)){

                        ImageDrawRectangle(&maze_img, i_x * tile_width + tile_width / 4, i_y * tile_height + tile_height, tile_width / 2, tile_height / 2, RED);

                    }

                    if(i_x - 1 >= 0 && tile_map[i_y][i_x - 1].tile_type_id == -1 && is_side_open(3, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id, tile_map[i_y][i_x].tile_fraction_x)){

                        ImageDrawRectangle(&maze_img, i_x * tile_width - tile_width / 2, i_y * tile_height + tile_height / 4, tile_width / 2, tile_height / 2, YELLOW);

                    }

                    if(tile_map[i_y][i_x].direction == 0){

                        ImageColorTint(&temp, BLUE);

                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    } else if(tile_map[i_y][i_x].direction == 1){

                        ImageColorTint(&temp, GREEN);

                        ImageRotateCW(&temp);
                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    } if(tile_map[i_y][i_x].direction == 2){

                        ImageColorTint(&temp, RED);

                        ImageRotateCW(&temp);
                        ImageRotateCW(&temp);
                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    }if(tile_map[i_y][i_x].direction == 3){

                        ImageColorTint(&temp, YELLOW);

                        ImageRotateCCW(&temp);
                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    }

                }
            
            }

        }

    }

    //prints all info of said tile
    void debug_print_tile(Vector2 position){

        std::cout << "x:" << position.x << ",y:" << position.y << ",type:" << tile_map[position.y][position.x].tile_type_id << ",direction:" << tile_map[position.y][position.x].direction << "\n";

    }
    
    //prints the whole tilemap contents to the console(spammmmmm)
    void debug_print_tile_map(){

        for(int i_y = 0; i_y < tile_map_height; i_y++){

            for(int i_x = 0; i_x < tile_map_width; i_x++){

                std::cout << "|x:"<< i_x << ",y:" << i_y << ",type:" << tile_map[i_y][i_x].tile_type_id << ",dir" << tile_map[i_y][i_x].direction << "|\t";

            }

            std::cout << "\n\n";

        }

    }

    void debug_print_tile_type(int index){
        std::cout << "-------------------------------------------------------------------------------------\n";        
        std::cout << "Debug info: Tile " << index << ".\n";
        std::cout << "Tile width: " << tile_types[index].width << ", tile height: " <<  tile_types[index].width << ".\n";
        std::cout << "Image path: " << tile_types[index].image_path << ".\n";
        std::cout << "image Data. Format: " << tile_types[index].type_image.format << ", img width: " << tile_types[index].type_image.width << ", img height: " << tile_types[index].type_image.height << ".\n";
        std::cout << "Default propabillity: " << tile_types[index].default_propabillity << ".\n";
        std::cout << "Propabillity specifiers:\n";
        for(int i = 0; i < tile_types[index].propabillity_specifiers.size(); i++){

            std::cout << tile_types[index].propabillity_specifiers[i].index << ": " << tile_types[tile_types[index].propabillity_specifiers[i].index].type_name << ": " << tile_types[index].propabillity_specifiers[i].propabillity << ". ";


        }

        std::cout << "\nnorth: ";
        for(int i = 0; i < tile_types[index].north.size(); i++){

            std::cout << tile_types[index].north[i] << ", ";
        }

        std::cout << "east: ";
        for(int i = 0; i < tile_types[index].east.size(); i++){

            std::cout << tile_types[index].east[i] << ", ";
        }

        std::cout << "south: ";
        for(int i = 0; i < tile_types[index].south.size(); i++){

            std::cout << tile_types[index].south[i] << ", ";

        }

        std::cout << "west: ";
        for(int i = 0; i < tile_types[index].west.size(); i++){

            std::cout << tile_types[index].west[i] << ", ";
        }
        std::cout << "\n";

        for(int i = 0; i < tile_types.size();i++){

            tile_types[i].sum_propabillity_specific = 0; //initialize sum_propabillity_specific as 0

            //and for each type relative to each other type
            for(int i_specific = 0; i_specific < tile_types.size(); i_specific++){

                tile_types[i].sum_propabillity_specific += get_specified_propabillity(i_specific, i); // set sum_propabillity_specific to be the sum of all specified propabillities for that type.

            }
            
 
        }

    }

    void debug_print_tile_types(){

        for(int i = 0; i < tile_types.size(); i++){

            debug_print_tile_type(i);

        }

    }

    //export maze as png file in export directory
    void safe_maze(std::string name){

        static std::string name_temp;
        static std::time_t currentTime; 
        static std::string current_time;
        
        currentTime = std::time(nullptr);
        
        current_time = std::asctime(std::localtime(&currentTime));
        current_time.pop_back();
        name_temp = "export/" + current_time + "," + name;
        

        ExportImage(maze_img, name_temp.c_str());

    }


    void save_tile_types(std::string file_path){

        std::ofstream file_out(file_path.c_str(), std::ios_base::out);
        Json::Value root;

        for(int i = 0; i < tile_types.size(); i++){

            root[i] = tile_types[i].get_json();

        }

        file_out << root;
        std::cout << "Successfully saved to file\n";


    }

    void load_tile_types(std::string file_path){

        std::ifstream file_in(file_path.c_str(), std::ios_base::in);
        if(!file_in.is_open()){

            std::cout << "There is no file: " << file_path << ". Fuck you.\n";
            return;

        }
        
        Json::Value root;
        
        file_in >> root;

        tile_types.resize(root.size());
        
        for(int i = 0; i < root.size(); i++){
            
            std::cout << "\nObject at index " << i << ";" << "\n";
            tile_types[i].load_from_json(root[i]);
        }

        std::cout << "Sucessfully loaded tile types :3\n";

    }

};