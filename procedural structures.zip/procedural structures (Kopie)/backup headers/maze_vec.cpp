#include "../raylib/raylib.h"
#include <string>
#include <cstring>
#include <vector>
#include <iostream>
#include <random>
#include <ctime>


void ImageDrawImage(Image &target_image, Image &current_image, int x, int y) {

    for(int i_y = 0; i_y < current_image.height; i_y++){

        for(int i_x = 0; i_x < current_image.width; i_x++){

            ImageDrawPixel(&target_image, i_x + x, i_y + y, GetImageColor(current_image, i_x, i_y));
        
        }

    }

}

struct propabillity_specifier{ // specifies that this tile type has increased neighbour spawn rates of specific other tile types. 

    int index;
    int propabillity;

};

struct tile_type{



    std::string type_name;
    
    int width, height;
    
    Image type_image;
    float default_propabillity; // to spawn in %.
    std::vector<propabillity_specifier> propabillity_specifiers; // propabillity multiplier for specified neighbouring tile_types to spawn.
    std::vector<bool> north;
    std::vector<bool> east;
    std::vector<bool> south;
    std::vector<bool> west;

    tile_type(std::string type_name_p, int width_p, int height_p, Image type_image_p, float default_propabillity_p, std::vector<propabillity_specifier> propabillity_specifiers_p, std::vector<bool> north_p, std::vector<bool> east_p, std::vector<bool> south_p, std::vector<bool> west_p){

        type_name = type_name_p;
        width = width_p;
        height = height_p;
        type_image = ImageCopy(type_image_p);
        default_propabillity = default_propabillity_p;
        propabillity_specifiers = propabillity_specifiers_p;

        north = north_p;
        east = east_p;
        south = south_p;
        west = west_p;

    }

    int sum_propabillity_specific = 0;
    bool specified_propabillity = false;
};

struct tile{

    int tile_type_id = -1;
    int direction = 0;
    int tile_fraction_x = 1, tile_fraction_y = 1;

};



class maze{

public:
    int tile_map_width, tile_map_height, tile_width, tile_height;

    int sum_propabillity_default = 0;

    std::vector<tile_type> tile_types;
    std::vector<std::vector<tile>> tile_map;

    Image maze_img;
    


    maze(int tile_map_width_p, int tile_map_height_p, int tile_width_p, int tile_height_p){

        tile_map.resize(tile_map_width_p, std::vector<tile>(tile_map_height_p));

        tile_map_width = tile_map_width_p;
        tile_map_height = tile_map_height_p;
        tile_width = tile_width_p;
        tile_height = tile_height_p;

        maze_img = GenImageColor(tile_map_width * tile_width, tile_map_height * tile_height, BLACK);

        srand(std::time(0));

    }
    //-------------------------------------------------------------------------------------------------------------
    //tile map modifications:
    
    //modifies the type of a tile at said position
    void set_tile_type(Vector2 position_p, int tile_type_id_p){

        tile_map[position_p.y][position_p.x].tile_type_id = tile_type_id_p;

    }
    
    //modifies the direction of a tile at said position
    void set_tile_direction(Vector2 position_p, int direction_p){

        tile_map[position_p.y][position_p.x].direction = direction_p;

    }
    
    //rotates the tile left by changing its direction acordingly
    void rotate_tile_left(Vector2 position_p){

        if(tile_map[position_p.y][position_p.x].direction == 0){

            tile_map[position_p.y][position_p.x].direction = 3;

        } else if(tile_map[position_p.y][position_p.x].direction == 1){

            tile_map[position_p.y][position_p.x].direction = 0;

        } else if(tile_map[position_p.y][position_p.x].direction == 2){

            tile_map[position_p.y][position_p.x].direction = 1;

        } else {

            tile_map[position_p.y][position_p.x].direction = 2;

        }

    }
    
    //rotates the tile left by changing its direction acordingly
    void rotate_tile_right(Vector2 position_p){

        if(tile_map[position_p.y][position_p.x].direction == 0){

            tile_map[position_p.y][position_p.x].direction = 1;

        } else if(tile_map[position_p.y][position_p.x].direction == 1){

            tile_map[position_p.y][position_p.x].direction = 2;

        } else if(tile_map[position_p.y][position_p.x].direction == 2){

            tile_map[position_p.y][position_p.x].direction = 3;

        } else {

            tile_map[position_p.y][position_p.x].direction = 0;

        }

    }

    //sets a specified tile onto the tilemap at said position
    void set_tile(int x, int y, int tile_type_id_p, int direction_p){

        tile_map[y][x].tile_type_id = tile_type_id_p;
        tile_map[y][x].direction = direction_p;

        for(int i_y = 0; i_y < tile_types[tile_type_id_p].height; i_y++){

            for(int i_x = 0; i_x < tile_types[tile_type_id_p].width; i_x++){

                tile_map[y][x].tile_fraction_x = i_x;
                tile_map[y][x].tile_fraction_y = i_y;

            }

        }

    }

    //places a random tile applying specified randomness defined in each tiles type as far as such something exists
    void set_random_tile(int x, int y, int direction_p, int originating_type){
        static int sum_iterator;
        static int random_value;

        random_value = std::rand() % tile_types[originating_type].sum_propabillity_specific;
        sum_iterator = 0;


        for(int i = 0; i < tile_types.size(); i++){
            
            sum_iterator += get_specified_propabillity(i, originating_type);

            if(sum_iterator > random_value){

                set_tile(x, y, i, direction_p);
                //std::cout << i << ":" << tile_types[originating_type].sum_propabillity_specific << "," << random_value << "," << sum_iterator << "\n";
                return;

            }

        }

    }
    
    //resizes the height/width of heightmap(yes i know i am brilliant):
    void resize_tile_map(int width, int height){

        tile_map.resize(width, std::vector<tile>(height));

    }

    //-------------------------------------------------------------------------------------------------------------
    //tile map info:

    //checks if a absolute side of a tile considering its type and direction is open
    bool is_side_open(int side_direction, int tile_rotation, tile_type type, int side_fraction_index){

        //side direction = absolute direction,
        //tile direction = rotation of the tile

        if(side_direction == 0){ // north

            if(tile_rotation == 0){

                return type.north[side_fraction_index];
                
            } else if(tile_rotation == 1){

                return type.west[side_fraction_index];
                
            } else if(tile_rotation == 2){

                return type.south[side_fraction_index];
                
            } else {

                return type.east[side_fraction_index];

            }

            

        } else if(side_direction == 1){ // east

            if(tile_rotation == 0){

                return type.east[side_fraction_index];
                
            } else if(tile_rotation == 1){

                return type.north[side_fraction_index];
                
            } else if(tile_rotation == 2){

                return type.west[side_fraction_index];
                
            } else {

                return type.south[side_fraction_index];

            }

        } else if(side_direction == 2){ // south
     
            if(tile_rotation == 0){

                return type.south[side_fraction_index];
                
            } else if(tile_rotation == 1){

                return type.east[side_fraction_index];
                
            } else if(tile_rotation == 2){

                return type.north[side_fraction_index];
                
            } else {

                return type.west[side_fraction_index];

            }

        } else { // west

            if(tile_rotation == 0){

                return type.west[side_fraction_index];
                
            } else if(tile_rotation == 1){

                return type.south[side_fraction_index];
                
            } else if(tile_rotation == 2){

                return type.east[side_fraction_index];
                
            } else {

                return type.north[side_fraction_index];

            }

        }

        return false;

    }
    
    //checks if two neighbouring tiles are open to each other
    /*!!!NOT MULTITILE TYPE COMPATIBLE YET
    bool is_connected(int tile_1_x, int tile_1_y, int direction){

        if(direction == 0 && tile_map[tile_1_y - 1][tile_1_x].tile_type_id != -1){

            if(is_side_open(direction, tile_map[tile_1_y][tile_1_x].direction, tile_types[tile_map[tile_1_y][tile_1_x].tile_type_id]) &&
               is_side_open((direction + 2) >= 4 ? (direction + 2) - 4 : (direction + 2), tile_map[tile_1_y - 1][tile_1_x].direction, tile_types[tile_map[tile_1_y - 1][tile_1_x].tile_type_id])){

                return true;

            } else return false;

        } else if(direction == 1 && tile_map[tile_1_y][tile_1_x + 1].tile_type_id != -1){

            if(is_side_open(direction, tile_map[tile_1_y][tile_1_x].direction, tile_types[tile_map[tile_1_y][tile_1_x].tile_type_id]) &&
               is_side_open((direction + 2) >= 4 ? (direction + 2) - 4 : (direction + 2), tile_map[tile_1_y][tile_1_x + 1].direction, tile_types[tile_map[tile_1_y][tile_1_x + 1].tile_type_id])){

                return true;

            } else return false;

        } else if(direction == 2 && tile_map[tile_1_y + 1][tile_1_x].tile_type_id != -1){

            if(is_side_open(direction, tile_map[tile_1_y][tile_1_x].direction, tile_types[tile_map[tile_1_y][tile_1_x].tile_type_id]) &&
               is_side_open((direction + 2) >= 4 ? (direction + 2) - 4 : (direction + 2), tile_map[tile_1_y + 1][tile_1_x].direction, tile_types[tile_map[tile_1_y + 1][tile_1_x].tile_type_id])){

                return true;

            } else return false;

        } else if(direction == 3 && tile_map[tile_1_y][tile_1_x - 1].tile_type_id != -1) {

            if(is_side_open(direction, tile_map[tile_1_y][tile_1_x].direction, tile_types[tile_map[tile_1_y][tile_1_x].tile_type_id]) &&
               is_side_open(direction + 2, tile_map[tile_1_y][tile_1_x - 1].direction, tile_types[tile_map[tile_1_y][tile_1_x - 1].tile_type_id])){

                return true;

            } else return false;

        }

        return false;

    }
    */
    //restores tilemap to default state removing all tile info
    void clear_tile_map(){

        for(int i_y = 0; i_y < tile_map_height;i_y++){

            for(int i_x = 0; i_x < tile_map_height;i_x++){

                tile_map[i_y][i_x].direction = 0;
                tile_map[i_y][i_x].tile_type_id = -1;
            
            }

        }

    }

    //generates the maze by modifying the tilemap
    /*void generate_maze(int iterations){

        for(int i = 0; i < iterations; i++){

            for(int i_y = 0; i_y < tile_map_height; i_y++){

                for(int i_x = 0; i_x < tile_map_width; i_x++){

                    if(tile_map[i_y][i_x].tile_type_id != -1){
                        
                        //north:
                        if(i_y - 1 >= 0 && tile_map[i_y - 1][i_x].tile_type_id == -1 && is_side_open(0, tile_map[i_y][i_x].direction, tile_types[tile_map[i_y][i_x].tile_type_id])){

                            set_random_tile(i_x, i_y - 1, 0, tile_map[i_y][i_x].tile_type_id);

                        }

                        //east:
                        if(i_x + 1 < tile_map_width && tile_map[i_y][i_x + 1].tile_type_id == -1 && is_side_open(1, tile_map[i_y][i_x].direction, tile_types[tile_map[i_y][i_x].tile_type_id])){

                            set_random_tile(i_x + 1, i_y, 1, tile_map[i_y][i_x].tile_type_id);
                            
                        }

                        //south:
                        if(i_y + 1 < tile_map_height && tile_map[i_y + 1][i_x].tile_type_id == -1 && is_side_open(2, tile_map[i_y][i_x].direction, tile_types[tile_map[i_y][i_x].tile_type_id])){

                            set_random_tile(i_x, i_y + 1, 2, tile_map[i_y][i_x].tile_type_id);

                        }
                        
                        //west:
                        if(i_x - 1 >= 0 && tile_map[i_y][i_x - 1].tile_type_id == -1 && is_side_open(3, tile_map[i_y][i_x].direction, tile_types[tile_map[i_y][i_x].tile_type_id])){

                            set_random_tile(i_x - 1, i_y, 3, tile_map[i_y][i_x].tile_type_id);
                            
                        }
                        
                    }

                }

            }

        }

    }*/

    void generate_maze(int iterations){

        for(int i = 0; i < iterations; i++){

            for(int i_y = 0; i_y < tile_map_height; i_y++){

                for(int i_x = 0; i_x < tile_map_width; i_x++){

                    if(tile_map[i_y][i_x].tile_type_id != -1){
                        
                        //north:
                        if(i_y - 1 >= 0 && tile_map[i_y - 1][i_x].tile_type_id == -1 && is_side_open(0, tile_map[i_y][i_x].direction, tile_types[tile_map[i_y][i_x].tile_type_id], tile_map[i_y][i_x].tile_fraction_y)){

                            set_random_tile(i_x, i_y - 1, 0, tile_map[i_y][i_x].tile_type_id);

                        }

                        //east:
                        if(i_x + 1 < tile_map_width && tile_map[i_y][i_x + 1].tile_type_id == -1 && is_side_open(1, tile_map[i_y][i_x].direction, tile_types[tile_map[i_y][i_x].tile_type_id], tile_map[i_y][i_x].tile_fraction_x)){

                            set_random_tile(i_x + 1, i_y, 1, tile_map[i_y][i_x].tile_type_id);
                            
                        }

                        //south:
                        if(i_y + 1 < tile_map_height && tile_map[i_y + 1][i_x].tile_type_id == -1 && is_side_open(2, tile_map[i_y][i_x].direction, tile_types[tile_map[i_y][i_x].tile_type_id], tile_map[i_y][i_x].tile_fraction_y)){

                            set_random_tile(i_x, i_y + 1, 2, tile_map[i_y][i_x].tile_type_id);

                        }
                        
                        //west:
                        if(i_x - 1 >= 0 && tile_map[i_y][i_x - 1].tile_type_id == -1 && is_side_open(3, tile_map[i_y][i_x].direction, tile_types[tile_map[i_y][i_x].tile_type_id], tile_map[i_y][i_x].tile_fraction_x)){

                            set_random_tile(i_x - 1, i_y, 3, tile_map[i_y][i_x].tile_type_id);
                            
                        }
                        
                    }

                }

            }

        }

    }

    //-------------------------------------------------------------------------------------------------------------
    //tile type info:

    // checks if the current object specifies the propabillity of the target object.
    bool is_specified(int target_object_index, int current_object_index){

        for(int i = 0; i < tile_types[current_object_index].propabillity_specifiers.size(); i++){

            if(tile_types[current_object_index].propabillity_specifiers[i].index == target_object_index){

                return true;

            }

        }

        return false;

    }

    //returns value of specified propabillity for an object at given target_index, from the specifier array of object at given current_index. 
    int get_specified_propabillity(int target_index, int current_index){

        for(int i = 0; i < tile_types[current_index].propabillity_specifiers.size(); i++){

            if(tile_types[current_index].propabillity_specifiers[i].index == target_index){

                return tile_types[current_index].propabillity_specifiers[i].propabillity;

            }
            
        }

        return tile_types[target_index].default_propabillity;

    }

    //returns id of tile type with said name
    int get_type_id(std::string type_name_p){

        for(int i = 0; i < tile_types.size(); i++){

            if(tile_types[i].type_name == type_name_p){

                return i;

            }

        }

        return -1;

    }

    //returns type of tile with said name 
    tile_type get_type(std::string type_name_p){

        for(int i = 0; i < tile_types.size(); i++){

            if(tile_types[i].type_name == type_name_p){

                return tile_types[i];

            }

        }

        return tile_type{"none", 0, 0, GenImageColor(tile_width, tile_height, BLACK), 0, {}, {false}, {false}, {false}, {false}};

    }

    //-------------------------------------------------------------------------------------------------------------
    //tile type modifications:

    //adds a tile type and defines its specified propabillity according to the propabillity list.
    void add_tile_type(std::string type_name_p, int width_p, int height_p, Image type_image_p, float propabillity_default_p, std::vector<propabillity_specifier> propabillities_p, std::vector<bool> north_p, std::vector<bool> east_p, std::vector<bool> south_p, std::vector<bool>west_p){

        sum_propabillity_default += propabillity_default_p; // sum of all default propabillity values
        tile_types.push_back({type_name_p, width_p, height_p, type_image_p, propabillity_default_p, propabillities_p, north_p, east_p, south_p, west_p});

        for(int i = 0; i < tile_types.size();i++){

            tile_types[i].sum_propabillity_specific = 0;

            for(int i_specific = 0; i_specific < tile_types.size(); i_specific++){

                tile_types[i].sum_propabillity_specific += get_specified_propabillity(i_specific, i);

                

                /*if(is_specified(i_specific, i)){

                    tile_types[i].sum_propabillity_specific += get_specified_propabillity(i_specific, i);

                } else {

                    tile_types[i].sum_propabillity_specific += tile_types[i_specific].default_propabillity;

                }*/

            }

            //std::cout << "specific " << i << ":" << tile_types[i].sum_propabillity_specific << "\n";

        }

    }

    //*hold your breath* removes a tile type...(doesnt work right now as im too lazy to fix it)
    void remove_tile_type(std::string type_name_p){

        for(int i = 0; i < tile_types.size(); i++){

            if(tile_types[i].type_name == type_name_p){

                tile_types.erase(tile_types.begin() + i);

            }

        }

    }

    //-------------------------------------------------------------------------------------------------------------
    //tile image modifications:
    
    //renders the maze to the maze.img var.
    void render_maze(){

        Image temp;

        std::cout << "rendering...\n";

        for(int i_y = 0; i_y < tile_map_height; i_y++){

            for(int i_x = 0; i_x < tile_map_width; i_x++){

                if(tile_map[i_y][i_x].tile_type_id != -1){

                    temp = ImageCopy(tile_types[tile_map[i_y][i_x].tile_type_id].type_image);

                    if(tile_map[i_y][i_x].direction == 0){

                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    } else if(tile_map[i_y][i_x].direction == 1){

                        ImageRotateCW(&temp);
                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    } if(tile_map[i_y][i_x].direction == 2){

                        ImageRotateCW(&temp);
                        ImageRotateCW(&temp);
                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    }if(tile_map[i_y][i_x].direction == 3){

                        ImageRotateCCW(&temp);
                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    }

                }
            
            }

        }

    }
    
    //renders the maze to the maze.img yet with a lot of debug info
    void render_maze_debug(){

        Image temp;

        std::cout << "\ntypes:\n";

        for(int i = 0; i < tile_types.size(); i++){

            std::cout << tile_types[i].type_name << ",n:";
            std::cout << "north: ";
            for(int id = 0; id < tile_types[i].width; id++){

                std::cout << tile_types[i].north[id];

            }

            std::cout << "\n";

            std::cout << "east: ";
            for(int id = 0; id < tile_types[i].width; id++){

                std::cout << tile_types[i].east[id];

            }

            std::cout << "\n";

            std::cout << "south: ";
            for(int id = 0; id < tile_types[i].width; id++){

                std::cout << tile_types[i].south[id];

            }

            std::cout << "\n";

            std::cout << "west: ";
            for(int id = 0; id < tile_types[i].width; id++){

                std::cout << tile_types[i].west[id];

            }

            std::cout << "\n";

        }

        std::cout << "rendering...\n";

        std::cout << "__________________________________________________________________\n";

        for(int i_y = 0; i_y < tile_map_height; i_y++){

            for(int i_x = 0; i_x < tile_map_width; i_x++){

                if(tile_map[i_y][i_x].tile_type_id != -1){

                    /*std::cout << tile_map[i_y][i_x].tile_type_id << tile_map[i_y][i_x].direction
                    << ",n:" << is_side_open(0, tile_map[i_y][i_x].direction, tile_types[tile_map[i_y][i_x].tile_type_id])
                    << ",e:" << is_side_open(1, tile_map[i_y][i_x].direction, tile_types[tile_map[i_y][i_x].tile_type_id])
                    << ",s:" << is_side_open(2, tile_map[i_y][i_x].direction, tile_types[tile_map[i_y][i_x].tile_type_id])
                    << ",w:" << is_side_open(3, tile_map[i_y][i_x].direction, tile_types[tile_map[i_y][i_x].tile_type_id]) << "\n";*/

                    temp = ImageCopy(tile_types[tile_map[i_y][i_x].tile_type_id].type_image);

                    if(i_y - 1 >= 0 && tile_map[i_y - 1][i_x].tile_type_id == -1 && is_side_open(0, tile_map[i_y][i_x].direction, tile_types[tile_map[i_y][i_x].tile_type_id], tile_map[i_y][i_x].tile_fraction_y)){

                        ImageDrawRectangle(&maze_img, i_x * tile_width + tile_width / 4, i_y * tile_height - tile_height / 2, tile_width / 2, tile_height / 2, BLUE);
                        
                        

                    }

                    if(i_x + 1 < tile_map_width && tile_map[i_y][i_x + 1].tile_type_id == -1 && is_side_open(1, tile_map[i_y][i_x].direction, tile_types[tile_map[i_y][i_x].tile_type_id], tile_map[i_y][i_x].tile_fraction_x)){

                        ImageDrawRectangle(&maze_img, i_x * tile_width + tile_width, i_y * tile_height + tile_height / 4, tile_width / 2, tile_height / 2, GREEN);
                        
                    }

                    if(i_y + 1 < tile_map_height && tile_map[i_y + 1][i_x].tile_type_id == -1 && is_side_open(2, tile_map[i_y][i_x].direction, tile_types[tile_map[i_y][i_x].tile_type_id], tile_map[i_y][i_x].tile_fraction_y)){

                        ImageDrawRectangle(&maze_img, i_x * tile_width + tile_width / 4, i_y * tile_height + tile_height, tile_width / 2, tile_height / 2, RED);

                    }

                    if(i_x - 1 >= 0 && tile_map[i_y][i_x - 1].tile_type_id == -1 && is_side_open(3, tile_map[i_y][i_x].direction, tile_types[tile_map[i_y][i_x].tile_type_id], tile_map[i_y][i_x].tile_fraction_x)){

                        ImageDrawRectangle(&maze_img, i_x * tile_width - tile_width / 2, i_y * tile_height + tile_height / 4, tile_width / 2, tile_height / 2, YELLOW);

                    }

                    if(tile_map[i_y][i_x].direction == 0){

                        ImageColorTint(&temp, BLUE);

                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    } else if(tile_map[i_y][i_x].direction == 1){

                        ImageColorTint(&temp, GREEN);

                        ImageRotateCW(&temp);
                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    } if(tile_map[i_y][i_x].direction == 2){

                        ImageColorTint(&temp, RED);

                        ImageRotateCW(&temp);
                        ImageRotateCW(&temp);
                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    }if(tile_map[i_y][i_x].direction == 3){

                        ImageColorTint(&temp, YELLOW);

                        ImageRotateCCW(&temp);
                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    }

                }
            
            }

        }

    }

    //prints all info of said tile
    void debug_print_tile(Vector2 position){

        std::cout << "x:" << position.x << ",y:" << position.y << ",type:" << tile_map[position.y][position.x].tile_type_id << ",direction:" << tile_map[position.y][position.x].direction << "\n";

    }
    
    //prints the whole tilemap contents to the console(spammmmmm)
    void debug_print_tile_map(){

        for(int i_y = 0; i_y < tile_map_height; i_y++){

            for(int i_x = 0; i_x < tile_map_width; i_x++){

                std::cout << "|x:"<< i_x << ",y:" << i_y << ",type:" << tile_map[i_y][i_x].tile_type_id << ",dir" << tile_map[i_y][i_x].direction << "|\t";

            }

            std::cout << "\n\n";

        }

    }

    //export maze as png file in export directory
    void safe_maze(std::string name){

        static std::string name_temp;
        static std::time_t currentTime; 
        static std::string current_time;
        
        currentTime = std::time(nullptr);
        
        current_time = std::asctime(std::localtime(&currentTime));
        current_time.pop_back();
        name_temp = "export/" + current_time + "," + name;
        

        ExportImage(maze_img, name_temp.c_str());

    }

};