#include "../raylib/raylib.h"
#include <ios>
#include <json/value.h>
#include <ostream>
#include <sstream>
#include <string>
#include <utility>
#include <vector>
#include <iostream>
#include <ctime>
#include <json/json.h>
#include <fstream>
#include <algorithm>


void ImageDrawImage(Image &target_image, Image &current_image, int x, int y) {

    for(int i_y = 0; i_y < current_image.height; i_y++){

        for(int i_x = 0; i_x < current_image.width; i_x++){

            ImageDrawPixel(&target_image, i_x + x, i_y + y, GetImageColor(current_image, i_x, i_y));
        
        }

    }

}

struct propability_specifier{ // specifies that this tile type has increased neighbour spawn rates of specific other tile types. 

    int index;
    int propability;

};

struct propability_tag {

    std::string tag;
    int propability;

};

struct tile_type{

    std::string type_name;
    std::vector<std::string> tags;
    int width, height;
    Image type_image;
    std::string image_path;
    float default_propability; // to spawn in %.
    std::vector<propability_specifier> propability_specifiers; // propability multiplier for specified neighbouring tile_types to spawn.
    std::vector<propability_tag> propability_tags;
    
    std::vector<bool> north; 
    std::vector<bool> east;
    std::vector<bool> south;
    std::vector<bool> west;

    tile_type(std::string type_name_p, std::vector<std::string> tags,  int width_p, int height_p, std::string image_path, float default_propability_p, std::vector<propability_specifier> propability_specifiers_p, std::vector<propability_tag> propability_tags,  std::vector<bool> north_p, std::vector<bool> east_p, std::vector<bool> south_p, std::vector<bool> west_p){

        this->type_name = type_name_p;
        this->tags = tags;
        this->width = width_p;
        this->height = height_p;
        this->type_image = LoadImage(image_path.c_str());
        this->image_path = image_path;
        this->default_propability = default_propability_p;
        this->propability_specifiers = propability_specifiers_p;
        this->propability_tags = propability_tags;

        this->north = north_p;
        this->east = east_p;
        this->south = south_p;
        this->west = west_p;

    }

    tile_type(){}

    int sum_propability_specific = 0;
    bool specified_propability = false;

    Json::Value get_json() {

        Json::Value json;
        json["type_name"] = type_name;
        for(int i = 0; i < tags.size(); i++){

            json["tags"].append(tags[i]);

        }

        json["width"] = width;
        json["height"] = height;
        json["image_path"] = image_path;
        json["default_propability"] = default_propability;

        for (int i = 0; i < propability_tags.size(); i++) {
            json["propability_tags"][i]["propability"] = propability_tags[i].propability;
            json["propability_tags"][i]["tag"] = propability_tags[i].tag;
        }


        for (bool val : north) json["north"].append(val);

        for (bool val : east) json["east"].append(val);

        for (bool val : south) json["south"].append(val);

        for (bool val : west) json["west"].append(val);

        return json;
    }

    void load_from_json(Json::Value json) {
    // Load basic properties
        type_name = json["type_name"].asString();
        width = json["width"].asInt();
        height = json["height"].asInt();
        type_image = LoadImage(json["image_path"].asCString());
        image_path = json["image_path"].asString();
        default_propability = json["default_propability"].asFloat();

        // Clear the vectors before loading new values
        tags.clear();
        propability_tags.clear();
        propability_specifiers.clear();
        north.clear();
        east.clear();
        south.clear();
        west.clear();

        // Load tags
        for (const auto& tag : json["tags"]) {
            tags.push_back(tag.asString());
        }

        // Load propability_tags
        for (const auto& tag : json["propability_tags"]) {
            propability_tag p_tag;
            p_tag.propability = tag["propability"].asFloat();
            p_tag.tag = tag["tag"].asString();
            propability_tags.push_back(p_tag);
        }

        // Load propability_specifiers (assuming you need this too)
        for (const auto& spec : json["propability_specifiers"]) {
            propability_tag propabillity_tag;
            propabillity_tag.propability = spec["propability"].asFloat();
            propabillity_tag.tag = spec["tag"].asString();
            propability_tags.push_back(propabillity_tag);
        }

        // Load directional vectors
        for (const auto& val : json["north"]) north.push_back(val.asBool());
        for (const auto& val : json["east"]) east.push_back(val.asBool());
        for (const auto& val : json["south"]) south.push_back(val.asBool());
        for (const auto& val : json["west"]) west.push_back(val.asBool());
    }
    
};

struct tile{

    int tile_type_id = -1;
    int direction = 0;
    int tile_fraction_x = 0, tile_fraction_y = 0;

};

class maze{

public:
    int tile_map_width, tile_map_height, tile_width, tile_height;

    int sum_propability_default = 0;

    std::vector<tile_type> tile_types;
    std::vector<std::vector<tile>> tile_map;
    Json::Value root;
    std::string file_path;

    Image maze_img;
    

    maze(int tile_map_width_p, int tile_map_height_p, int tile_width_p, int tile_height_p){
        tile_map.resize(tile_map_width_p, std::vector<tile>(tile_map_height_p));

        tile_map_width = tile_map_width_p;
        tile_map_height = tile_map_height_p;
        tile_width = tile_width_p;
        tile_height = tile_height_p;

        maze_img = GenImageColor(tile_map_width * tile_width, tile_map_height * tile_height, BLACK);

        srand(std::time(0));

    }
    //-------------------------------------------------------------------------------------------------------------
    //tile map modifications:
    
    //modifies the type of a tile at said position
    void r_type(Vector2 position_p, int tile_type_id_p){

        tile_map[position_p.y][position_p.x].tile_type_id = tile_type_id_p;

    }
    
    //modifies the direction of a tile at said position
    void set_tile_direction(Vector2 position_p, int direction_p){

        tile_map[position_p.y][position_p.x].direction = direction_p;

    }
    /*
    //rotates the tile left by changing its direction acordingly
    void rotate_tile_left(Vector2 position_p){

        if(tile_map[position_p.y][position_p.x].direction == 0){

            tile_map[position_p.y][position_p.x].direction = 3;

        } else if(tile_map[position_p.y][position_p.x].direction == 1){

            tile_map[position_p.y][position_p.x].direction = 0;

        } else if(tile_map[position_p.y][position_p.x].direction == 2){

            tile_map[position_p.y][position_p.x].direction = 1;

        } else {

            tile_map[position_p.y][position_p.x].direction = 2;

        }

    }
    
    //rotates the tile left by changing its direction acordingly
    void rotate_tile_right(Vector2 position_p){

        if(tile_map[position_p.y][position_p.x].direction == 0){

            tile_map[position_p.y][position_p.x].direction = 1;

        } else if(tile_map[position_p.y][position_p.x].direction == 1){

            tile_map[position_p.y][position_p.x].direction = 2;

        } else if(tivoid ImageDrawImage(Image &target_image, Image &current_image, int x, int y) {

    for(int i_y = 0; i_y < current_image.height; i_y++){

        for(int i_x = 0; i_x < current_image.width; i_x++){

            ImageDrawPixel(&target_image, i_x + x, i_y + y, GetImageColor(current_image, i_x, i_y));
        
        }

    }

}

            tile_map[position_p.y][position_p.x].direction = 0;

        }

    }*/

    //sets a specified tile onto the tilemap at said position

    //TODO: IGNORES HEIGHT AND WIDTH DIFFERENCES WHEN TILE IS ROTATED!!! WILL ONLY WORK FOR QUADRATIC TILES!

    void set_tile(int x, int y, int tile_type_id, int direction){
 
        static int width, height;

        width = tile_types[tile_type_id].width;
        height = tile_types[tile_type_id].height;
        
        if(direction % 2 != 0) std::swap(width,height);

        for(int i_y = 0; i_y < height; i_y++){

            for(int i_x = 0; i_x < width; i_x++){

                if(i_y + y < tile_map_height && i_x + x < tile_map_width){

                    //std::cout << "y:" << i_y + y << "|" << "x:" << i_x + x << "\n";
                
                    tile_map[y + i_y][x + i_x].tile_type_id = tile_type_id;
                    tile_map[y + i_y][x + i_x].direction = direction;
                    tile_map[y + i_y][x + i_x].tile_fraction_x = i_x;
                    tile_map[y + i_y][x + i_x].tile_fraction_y = i_y;

                }

            }

        }

    }

    //places a random tile applying specified randomness defined in each tiles type as far as such something exists
    void set_random_tile(int x, int y, int direction_p, int originating_type){
        static int sum_iterator;
        static int random_value;


        //std::cout << "originating type: " << originating_type << ", sum propability specific of given type: " << tile_types[originating_type].sum_propability_specific << ".\n";

        if(tile_types[originating_type].sum_propability_specific != 0){

            random_value = std::rand() % tile_types[originating_type].sum_propability_specific;

        } else {

            random_value = 1;

        }
        
        sum_iterator = 0;



        for(int i = 0; i < tile_types.size(); i++){

            //std::cout << i << "," << originating_type << "\n";
            sum_iterator += get_specified_propability(i, originating_type);

            if(sum_iterator > random_value){

                set_tile(x, y, i, direction_p);
                //std::cout << i << ":" << tile_types[originating_type].sum_propability_specific << "," << random_value << "," << sum_iterator << "\n";
                return;

            }

        }

    }

    int get_random_tile(int originating_type){
        static int sum_iterator;
        static int random_value;


        //std::cout << "originating type: " << originating_type << ", sum propability specific of given type: " << tile_types[originating_type].sum_propability_specific << ".\n";

        if(tile_types[originating_type].sum_propability_specific != 0){

            random_value = std::rand() % tile_types[originating_type].sum_propability_specific;

        } else {

            random_value = 1;

        }
        
        sum_iterator = 0;



        for(int i = 0; i < tile_types.size(); i++){

            //std::cout << i << "," << originating_type << "\n";
            sum_iterator += get_specified_propability(i, originating_type);

            if(sum_iterator > random_value){
                //std::cout << i << ":" << tile_types[originating_type].sum_propability_specific << "," << random_value << "," << sum_iterator << "\n";
                return i;

            }

        }

        return -1;

    }

    //returns a rendom type specificly for the type it currently appends from
    int get_random_type(int originating_type){
        static int sum_iterator;
        static int random_value;

        random_value = std::rand() % tile_types[originating_type].sum_propability_specific;
        sum_iterator = 0;

        if(originating_type > -1 && originating_type < tile_types.size()){

            for(int i = 0; i < tile_types.size(); i++){
            
                //std::cout << i << "," << originating_type << "\n";
                sum_iterator += get_specified_propability(i, originating_type);

                if(sum_iterator > random_value){

                    return i;
                    //std::cout << i << ":" << tile_types[originating_type].sum_propability_specific << "," << random_value << "," << sum_iterator << "\n";

                }

            }

        }

        return -1;

    }
    
    //resizes the height/width of heightmap(yes i know i am brilliant):
    void resize_tile_map(int width, int height){

        tile_map.resize(width, std::vector<tile>(height));

    }

    //-------------------------------------------------------------------------------------------------------------
    //tile map info:

    //checks if a absolute side of a tile considering its type and direction is open

    bool is_side_open(int side_direction, int tile_direction, int tile_type_id, int node){

        //side direction = absolute direction,
        //tile direction = rotation of the tile

        if(side_direction == 0){ // north

            if(tile_direction == 0){

                return tile_types[tile_type_id].north[node];
                
            } else if(tile_direction == 1){

                return tile_types[tile_type_id].west[node];
                
            } else if(tile_direction == 2){

                return tile_types[tile_type_id].south[node];
                
            } else {

                return tile_types[tile_type_id].east[node];

            }

        } else if(side_direction == 1){ // east

            if(tile_direction == 0){

                return tile_types[tile_type_id].east[node];
                
            } else if(tile_direction == 1){

                return tile_types[tile_type_id].north[node];
                
            } else if(tile_direction == 2){

                return tile_types[tile_type_id].west[node];
                
            } else {

                return tile_types[tile_type_id].south[node];

            }

        } else if(side_direction == 2){ // south
     
            if(tile_direction == 0){

                return tile_types[tile_type_id].south[node];
                
            } else if(tile_direction == 1){

                return tile_types[tile_type_id].east[node];
                
            } else if(tile_direction == 2){

                return tile_types[tile_type_id].north[node];
                
            } else {

                return tile_types[tile_type_id].west[node];

            }

        } else { // west

            if(tile_direction == 0){

                return tile_types[tile_type_id].west[node];
                
            } else if(tile_direction == 1){

                return tile_types[tile_type_id].south[node];
                
            } else if(tile_direction == 2){

                return tile_types[tile_type_id].east[node];
                
            } else {

                return tile_types[tile_type_id].north[node];

            }

        }

        return false;

    }

    bool is_empty(int pos_x, int pos_y, int width, int height) {
        
        for(int i_y = pos_y; i_y < pos_y + height; i_y++) {

            for(int i_x = pos_x; i_x < pos_x + width; i_x++) {


                if(tile_map[i_y][i_x].tile_type_id != -1 || i_x < 0 || i_y < 0 || i_x > tile_map_width || i_y > tile_map_height) {

                    return false;

                }

            }

        }

        return true;

    }
    
    //checks if two neighbouring tiles are open to each other

    /*!!!NOT MULTITILE TYPE COMPATIBLE YET
    bool is_connected(int tile_1_x, int tile_1_y, int direction){

        if(direction == 0 && tile_map[tile_1_y - 1][tile_1_x].tile_type_id != -1){

            if(is_side_open(direction, tile_map[tile_1_y][tile_1_x].direction, tile_types[tile_map[tile_1_y][tile_1_x].tile_type_id]) &&
               is_side_open((direction + 2) >= 4 ? (direction + 2) - 4 : (direction + 2), tile_map[tile_1_y - 1][tile_1_x].direction, tile_types[tile_map[tile_1_y - 1][tile_1_x].tile_type_id])){

                return true;

            } else return false;

        } else if(direction == 1 && tile_map[tile_1_y][tile_1_x + 1].tile_type_id != -1){

            if(is_side_open(direction, tile_map[tile_1_y][tile_1_x].direction, tile_types[tile_map[tile_1_y][tile_1_x].tile_type_id]) &&
               is_side_open((direction + 2) >= 4 ? (direction + 2) - 4 : (direction + 2), tile_map[tile_1_y][tile_1_x + 1].direction, tile_types[tile_map[tile_1_y][tile_1_x + 1].tile_type_id])){

                return true;

            } else return false;

        } else if(direction == 2 && tile_map[tile_1_y + 1][tile_1_x].tile_type_id != -1){

            if(is_side_open(direction, tile_map[tile_1_y][tile_1_x].direction, tile_types[tile_map[tile_1_y][tile_1_x].tile_type_id]) &&
               is_side_open((direction + 2) >= 4 ? (direction + 2) - 4 : (direction + 2), tile_map[tile_1_y + 1][tile_1_x].direction, tile_types[tile_map[tile_1_y + 1][tile_1_x].tile_type_id])){

                return true;

            } else return false;

        } else if(direction == 3 && tile_map[tile_1_y][tile_1_x - 1].tile_type_id != -1) {

            if(is_side_open(direction, tile_map[tile_1_y][tile_1_x].direction, tile_types[tile_map[tile_1_y][tile_1_x].tile_type_id]) &&
               is_side_open(direction + 2, tile_map[tile_1_y][tile_1_x - 1].direction, tile_types[tile_map[tile_1_y][tile_1_x - 1].tile_type_id])){

                return true;

            } else return false;

        }

        return false;

    }
    */
    //restores tilemap to default state removing all tile info
    
    void clear_tile_map(){

        for(int i_y = 0; i_y < tile_map_height;i_y++){

            for(int i_x = 0; i_x < tile_map_height;i_x++){

                tile_map[i_y][i_x].direction = 0;
                tile_map[i_y][i_x].tile_type_id = -1;
                tile_map[i_y][i_x].tile_fraction_x = 0;
                tile_map[i_y][i_x].tile_fraction_y = 0;
            
            }

        }

    }

    //generates the maze by modifying the tilemap
    /*void generate_maze(int iterations){

        for(int i = 0; i < iterations; i++){

            for(int i_y = 0; i_y < tile_map_height; i_y++){

                for(int i_x = 0; i_x < tile_map_width; i_x++){

                    if(tile_map[i_y][i_x].tile_type_id != -1){
                        
                        //north:
                        if(i_y - 1 >= 0 && tile_map[i_y - 1][i_x].tile_type_id == -1 && is_side_open(0, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id)){

                            set_random_tile(i_x, i_y - 1, 0, tile_map[i_y][i_x].tile_type_id);

                        }

                        //east:
                        if(i_x + 1 < tile_map_width && tile_map[i_y][i_x + 1].tile_type_id == -1 && is_side_open(1, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id)){

                            set_random_tile(i_x + 1, i_y, 1, tile_map[i_y][i_x].tile_type_id);
                            
                        }

                        //south:
                        if(i_y + 1 < tile_map_height && tile_map[i_y + 1][i_x].tile_type_id == -1 && is_side_open(2, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id)){

                            set_random_tile(i_x, i_y + 1, 2, tile_map[i_y][i_x].tile_type_id);

                        }
                        
                        //west:
                        if(i_x - 1 >= 0 && tile_map[i_y][i_x - 1].tile_type_id == -1 && is_side_open(3, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id)){

                            set_random_tile(i_x - 1, i_y, 3, tile_map[i_y][i_x].tile_type_id);
                            
                        }
                        
                    }

                }

            }

        }

    }*/
    
    void generate_maze_old(int iterations){
        
        static float percentage;
        percentage = 0;

        for(int i = 0; i < iterations; i++){
            

            percentage = (float)(i + 1) / iterations * 100;
            std::cout << "\rProgress: " << percentage << std::flush;
            for(int i_y = 0; i_y < tile_map_height; i_y++){

                for(int i_x = 0; i_x < tile_map_width; i_x++){
                
                    if(tile_map[i_y][i_x].tile_type_id != -1){
    
                        if(i_y - 1 > -1 && tile_map[i_y - 1][i_x].tile_type_id == -1 && is_side_open(0, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id, 0)){
                        
                            set_random_tile(i_x, i_y - 1, 0, tile_map[i_y][i_x].tile_type_id);
                            
                        }
    
                        if(i_x + 1 < tile_map_width && tile_map[i_y][i_x + 1].tile_type_id == -1 && is_side_open(1, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id, 0)){
                        
                            set_random_tile(i_x + 1, i_y, 1, tile_map[i_y][i_x].tile_type_id);
                            
                        }
                        
                        if(i_y + 1 < tile_map_height && tile_map[i_y + 1][i_x].tile_type_id == -1 && is_side_open(2, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id, 0)){
                        
                            set_random_tile(i_x, i_y + 1, 2, tile_map[i_y][i_x].tile_type_id);
                            
                        }
    
                        if(i_x - 1 > -1 && tile_map[i_y][i_x - 1].tile_type_id == -1 && is_side_open(3, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id, 0)){
                        
                            set_random_tile(i_x - 1, i_y, 3, tile_map[i_y][i_x].tile_type_id);
                            
                        }
                        //return;
    
                    }
    
                }
    
            }

        }

    }

    //New version. Supports multi tiled fields. Probably worse performance
    void generate_maze(int iterations){
        
        std::cout << "Generating";
        
        int random_tile_type_id;
        int random_free_node;

        for(int i = 0; i < iterations; i++){

            for(int i_y = 0; i_y < tile_map_height; i_y++){

                for(int i_x = 0; i_x < tile_map_width; i_x++){
                    
                    if(tile_map[i_y][i_x].tile_type_id >= 0 && tile_map[i_y][i_x].tile_fraction_x == 0 && tile_map[i_y][i_x].tile_fraction_y == 0){

                        set_tile_neighbours(i_x, i_y);

                    }

                }

            }

        }

    }

    int get_random_free_node(std::vector<bool> &nodes){
        //assuming 010010
        //assuming seed 1
        static int random_node;
        static int available_nodes;
        static int checked_nodes;
        available_nodes = 0;
        checked_nodes = -1;

        for(int i = 0; i < nodes.size(); i++){
            if(nodes[i]) available_nodes++;
        }

        
        random_node = std::rand() % available_nodes;

        for(int i = 0; i < nodes.size(); i++){
            if(nodes[i]) checked_nodes++;
            if(random_node == checked_nodes){
                //std::cout << "returned random node: " << i << "\n\n";
                return i;

            }

        }
        std::cout << "ERROR: NO FREE NODE NIGGA\n";
        return -1;
    }

    void set_tile_neighbours(int x, int y) {

        tile_type current_type = tile_types[tile_map[y][x].tile_type_id];

        rotate_tile(&current_type, 0, tile_map[y][x].direction);

        int tile_type_id = get_random_tile(tile_map[y][x].tile_type_id);
        int node = get_random_free_node(tile_types[tile_type_id].south);
        tile_type type = tile_types[tile_type_id];
        

        //for north
        //std::cout << "selected tile: " << type.type_name << ", node: " << node << ", width: " << type.width << ", height: " << type.height << "\n";
        for(int i = 0; i < current_type.north.size(); i++){

            if(current_type.north[i] && get_area_empty(x + i - node, y - type.height, type.width, type.height)){   

                //std::cout << "side north is free\n";
                set_tile(x + i - node, y - type.height, tile_type_id, 0);

                tile_type_id = get_random_tile(tile_map[y][x].tile_type_id);
                node = get_random_free_node(tile_types[tile_type_id].south);
                type = tile_types[tile_type_id];


            }

        }
        
        //for east
        //std::cout << "selected tile: " << type.type_name << ", node: " << node << ", width: " << type.width << ", height: " << type.height << "\n";
        for(int i = 0; i < current_type.east.size(); i++){
            rotate_tile(&type, 0, 1);
            if(current_type.east[i] && get_area_empty(x + current_type.width, y + i - node, type.width, type.height)){

                //std::cout << "side east is free\n";
                

                set_tile(x + current_type.width, y + i - node, tile_type_id, 1);

                tile_type_id = get_random_tile(tile_map[y][x].tile_type_id);
                node = get_random_free_node(tile_types[tile_type_id].south);
                type = tile_types[tile_type_id];

            }

        }

        for(int i = 0; i < current_type.south.size(); i++){
            rotate_tile(&type, 0, 2);
            if(current_type.south[i] && get_area_empty(x + i - (type.width - node - 1), y + current_type.height, type.width, type.height)){

                //std::cout << "side east is free\n";
                

                set_tile(x + i - (type.width - node - 1), y + current_type.height, tile_type_id, 2);

                tile_type_id = get_random_tile(tile_map[y][x].tile_type_id);
                node = get_random_free_node(tile_types[tile_type_id].south);
                type = tile_types[tile_type_id];

            }

        }





        //for west
        //std::cout << "selected tile: " << type.type_name << ", node: " << node << ", width: " << type.width << ", height: " << type.height << "\n";
        for(int i = 0; i < current_type.west.size(); i++){
            rotate_tile(&type, 0, 3);
            if(current_type.west[i] && get_area_empty(x - type.width, y + i - (type.height - node - 1), type.width, type.height)){

                //std::cout << "side west is free\n";
                

                set_tile(x - type.width, y + i - (type.height - node - 1), tile_type_id, 3);

                tile_type_id = get_random_tile(tile_map[y][x].tile_type_id);
                node = get_random_free_node(tile_types[tile_type_id].south);
                type = tile_types[tile_type_id];

            }

        }

    }

    bool get_area_empty(int x, int y, int width, int height) {
        
        // Check if the area is within bounds
        if (x < 0 || y < 0 || x + width > tile_map[0].size() || y + height > tile_map.size()) {
            return false;
        }

        // Check if the area is empty
        for (int i_y = y; i_y < y + height; i_y++) {
            for (int i_x = x; i_x < x + width; i_x++) {
                if (tile_map[i_y][i_x].tile_type_id != -1) {
                    return false;
                }
            }
        }
        return true;
    }

    void rotate_tile(tile_type *type, int current_direction, int target_direction) {
        // Calculate the number of 90-degree rotations needed
        int rotation_count = (target_direction - current_direction + 4) % 4;

        for (int i = 0; i < rotation_count; ++i) {
            // Perform a 90-degree clockwise rotation
            std::reverse(type->east.begin(), type->east.end());
            std::reverse(type->west.begin(), type->west.end());

            std::vector<bool> temp = type->west;

            type->west = type->south;
            type->south = type->east;
            type->east = type->north;
            type->north = temp;

            // Swap width and height
            std::swap(type->width, type->height);

        }

    }

    //-------------------------------------------------------------------------------------------------------------
    //tile type info:

    // checks if the current object specifies the propability of the target object.
    bool is_specified(int target_object_index, int current_object_index){

        for(int i = 0; i < tile_types[current_object_index].propability_specifiers.size(); i++){

            if(tile_types[current_object_index].propability_specifiers[i].index == target_object_index){

                return true;

            }

        }

        return false;

    }

    //returns value of specified propability for an object at given target_index, from the specifier array of object at given current_index. 
    int get_specified_propability(int target_index, int current_index){

        for(int i = 0; i < tile_types[current_index].propability_specifiers.size(); i++){

            if(tile_types[current_index].propability_specifiers[i].index == target_index){

                return tile_types[current_index].propability_specifiers[i].propability;

            }
            
        }

        return tile_types[target_index].default_propability;

    }

    //returns id of tile type with said name
    int get_type_id(std::string type_name_p){

        for(int i = 0; i < tile_types.size(); i++){

            if(tile_types[i].type_name == type_name_p){

                return i;

            }

        }

        return -1;

    }

    //returns type of tile with said name 
    tile_type get_type(std::string type_name){

        for(int i = 0; i < tile_types.size(); i++){

            if(tile_types[i].type_name == type_name){

                return tile_types[i];

            }

        }
        std::cout << "Tile type of name \"" << type_name << "\" not found. womp womp.\n";
        return tile_type{"none", {}, 0, 0, "could not find tile type", 0, {},{}, {false}, {false}, {false}, {false}};

    }

    bool is_integer(const std::string& str) {
    if (str.empty()) return false;  // Empty string is not valid

    // Check if each character is a digit
    for (char ch : str) {
        if (!std::isdigit(ch)) return false;
    }

    return true;
    }

    //command promt with type editing options.
    void type_editor(){

        std::string input;

        std::fstream file;
        std::cout << "----------------------------------------\n";
        std::cout << "Type editor. type help for info\n";

        while(input != "end"){

            std::getline(std::cin, input);
            

            if(input == "help"){
                std::cout << "----------------------------------------\n";
                std::cout << R"(load_json     //Selects a json using given path relative to the working directory.
new_json        //Creates a new json at given directory relative to working directory of project.
new_type        //Adds a new specified type to currently selected json file.
remove_type     //removes a specified type from the currently selected json file.
edit_type       //allows for editing a types perameters upon selection.
type_info       //displays all info of selected type.
type_list       //lists all types.
)";

            } else if(input == "load_json") {
                std::cout << "----------------------------------------\n";
                std::cout << "Enter file path to json: ";
                std::getline(std::cin, input);
                
                if(input == file_path){

                    std::cout << "file already loaded.\n";
                    continue;

                }

                if(!FileExists(input.c_str())){
                
                    std::cout << "There is no file: " << input << ". Skill issue.\n";
                    continue;

                }
                
                file.open(input.c_str(), std::ios_base::in | std::ios_base::out);
                
                file >> root;
                file.close();
                std::cout << "Json file loaded.\n";
                
                file_path = input;

            } else if(input == "new_json") {
                std::cout << "----------------------------------------\n";
                std::cout << "Enter name: ";

                std::string new_file_path;
                std::getline(std::cin, new_file_path);

                std::ifstream file_test(new_file_path);

                // Step 1: Check if the new file already exists
                if (file_test.is_open()) {
                    std::cout << "File already exists.\n";
                    file_test.close();
                    continue;  // Skip to the next iteration of the loop
                } else {
                    file_test.close();  // Close the file stream after the check

                    // Step 2: Ask to save changes to the previous file
                    std::cout << "Save changes to previous file (type y)?\n";
                    std::getline(std::cin, input);

                    if (input == "y") {
                        // Save changes to the previous file
                        std::ofstream prev_file(file_path, std::ios_base::out | std::ios_base::trunc);
                        if (prev_file.is_open()) {
                            prev_file << root;
                            prev_file.close();
                            std::cout << "Changes applied.\n";
                        } else {
                            std::cout << "Failed to save changes to the previous file.\n";
                        }
                    } else {
                        std::cout << "File changes not applied.\n";
                    }

                    // Step 3: Update file_path to the new file name
                    file_path = new_file_path;  // Correctly set file_path to the new file name

                    // Step 4: Clear the current root for the new file
                    root.clear();

                    std::cout << "New file selected and root cleared.\n";
                }
            } else if(input == "new_type") {
                std::cout << "----------------------------------------\n";
                tile_type new_type;

                //entering name
                std::cout << "Tile type name: ";
                std::getline(std::cin, input);
                new_type.type_name = input;

                std::cout << "Type tags next. Add them by typing your tag and pressing enter. When you are done, type \"next.\"\n";
                std::getline(std::cin, input);
                while(input != "next"){
                    
                    if(input == ""){

                        std::cout << "Tag cant be empty\n";
                        continue;

                    }
                    new_type.tags.push_back(input);
                    std::getline(std::cin, input);

                }

                //setting width
                std::cout << "Width(int): ";
                std::getline(std::cin, input);
                
                while(!is_integer(input)){

                    std::cout << "Bruh I said integer. like, a number yk? Try again: ";
                    std::getline(std::cin, input);

                }

                new_type.width = std::stoi(input);

                //setting height
                std::cout << "Height(int): ";
                std::getline(std::cin, input);
                
                while(!is_integer(input)){

                    std::cout << "Bruh I said integer. like, a number yk? Try again: ";
                    std::getline(std::cin, input);

                }

                new_type.height = std::stoi(input);

                //adding source image and image path
                std::cout << "Image path relative to executing directory: ";
                std::getline(std::cin, input);
                new_type.image_path = input;
                new_type.type_image = LoadImage(input.c_str());

                //default propabillity
                std::cout << "Default propabillity:\n";
                std::getline(std::cin, input);
                while(!is_integer(input)){

                    std::cout << "Bruh I said integer. like, a number yk? Try again: ";
                    std::getline(std::cin, input);

                }
                new_type.default_propability = std::stoi(input);
                
                //propabillity tags
                std::stringstream input_stream;

                std::cout << "Probability Tags next. Enter [string aka Tag] [int aka index]. Alternatively, enter name of existing runtime type to copy its values. When you are done, type \"next\"\n";



                while (true) {
                    std::getline(std::cin, input);



                    for(int i = 0; i < tile_types.size(); i++){

                        if(tile_types[i].type_name == input){

                            new_type.propability_tags = tile_types[i].propability_tags;
                            std::cout << "Copied values of type" << input << "\n";
                            
                            input = "next";
                            break;

                        }

                    }

                    if (input == "next") {
                        break; // Exit the loop if the user types "next"
                    }

                    input_stream.clear();
                    input_stream.str("");
                    input_stream.str(input);

                    propability_tag new_propabillity_tag;

                    // Extract tag and probability from input stream
                    if (!(input_stream >> new_propabillity_tag.tag >> new_propabillity_tag.propability)) {
                        std::cout << "Input Invalid. Please enter in format <string aka Tag> <int aka index>:\n";
                        continue; // Continue the loop if extraction failed
                    }

                    new_type.propability_tags.push_back(new_propabillity_tag);
                }
                //add north side bools

                static int node_val;
                new_type.north.resize(new_type.width);
                for (int i = 0; i < new_type.width; i++) {
                    std::cout << "For north side, boolean state of node " << i << " of " << new_type.width - 1 << " nodes[1|0]: ";
                    std::getline(std::cin, input);

                    try {
                        node_val = std::stoi(input);
                    } catch (std::invalid_argument& e) {
                        std::cout << "Needs to be boolean. either 1 or 0.\n";
                        i--; // Decrement to retry the current index.
                        continue;
                    }

                    if (node_val != 0 && node_val != 1) {
                        std::cout << "Needs to be boolean. either 1 or 0.\n";
                        i--; // Decrement to retry the current index.
                        continue;
                    }

                    new_type.north[i] = node_val;
                }

                new_type.east.resize(new_type.height);
                for (int i = 0; i < new_type.height; i++) {
                    std::cout << "For east side, boolean state of node " << i << " of " << new_type.height - 1 << " nodes[1|0]: ";
                    std::getline(std::cin, input);
                    
                    try {
                        node_val = std::stoi(input);
                    } catch (std::invalid_argument& e) {
                        std::cout << "Needs to be boolean. either 1 or 0.\n";
                        i--; // Decrement to retry the current index.
                        continue;
                    }
                
                    if (node_val != 0 && node_val != 1) {
                        std::cout << "Needs to be boolean. either 1 or 0.\n";
                        i--; // Decrement to retry the current index.
                        continue;
                    }
                
                    new_type.east[i] = node_val;
                }

                new_type.south.resize(new_type.width);
                for (int i = 0; i < new_type.width; i++) {
                    std::cout << "For south side, boolean state of node " << i << " of " << new_type.width - 1 << " nodes[1|0]: ";
                    std::getline(std::cin, input);
                    
                    try {
                        node_val = std::stoi(input);
                    } catch (std::invalid_argument& e) {
                        std::cout << "Needs to be boolean. either 1 or 0.\n";
                        i--; // Decrement to retry the current index.
                        continue;
                    }
                
                    if (node_val != 0 && node_val != 1) {
                        std::cout << "Needs to be boolean. either 1 or 0.\n";
                        i--; // Decrement to retry the current index.
                        continue;
                    }
                
                    new_type.south[i] = node_val;
                }

                new_type.west.resize(new_type.height);
                for (int i = 0; i < new_type.height; i++) {
                    std::cout << "For west side, boolean state of node " << i << " of " << new_type.height - 1 << " nodes[1|0]: ";
                    std::getline(std::cin, input);
                    
                    try {
                        node_val = std::stoi(input);
                    } catch (std::invalid_argument& e) {
                        std::cout << "Needs to be boolean. either 1 or 0.\n";
                        i--; // Decrement to retry the current index.
                        continue;
                    }
                
                    if (node_val != 0 && node_val != 1) {
                        std::cout << "Needs to be boolean. either 1 or 0.\n";
                        i--; // Decrement to retry the current index.
                        continue;
                    }
                
                    new_type.west[i] = node_val;
                }

                add_tile_type(new_type.type_name, new_type.tags, new_type.height, new_type.width, new_type.image_path, new_type.default_propability, new_type.propability_tags, new_type.north, new_type.east, new_type.south, new_type.west);
                root.append(new_type.get_json());
                evaluate_propability_specifiers();
                std::cout << "New type added to session root.\n";

            } else if(input == "remove_type") {
                std::cout << "----------------------------------------\n";
                std::cout << "Enter name of type: ";
                std::getline(std::cin, input);

                for(int i = 0; i < root.size(); i++) {
                    if(root[i]["type_name"].asString() == input) {
                        root.removeIndex(i, nullptr);
                        i--; // Decrement i to account for the removed element
                    }
                }
            } else if(input == "edit_type") {
                std::cout << "----------------------------------------\n";
                std::cout << "select type by name.\n";
                std::getline(std::cin, input);

                static int current_object;
                for(int i = 0; i < root.size(); i++) {
                    if(root[i]["type_name"].asString() == input) {
                        current_object = i;
                    }
                }

                std::cout << "select parameter. Type help now to see list of parameters ";
                std::getline(std::cin, input);
                if(input == "help"){

                    std::cout << "womp womp forgor\n";

                } else if(input == "name"){

                    std::cout << "Enter new name:\n";
                    std::getline(std::cin, input);
                    root[current_object]["type_name"] = input;

                } else if(input == "width"){

                    std::cout << "Enter new width: ";
                    std::getline(std::cin, input);
                    while(!(std::stoi(input))){

                        std::cout << "Needs to be integer.";
                        std::getline(std::cin, input);

                    }
                    root[current_object]["width"] = std::stoi(input);

                } else if(input == "height"){

                    std::cout << "Enter new height: ";
                    std::getline(std::cin, input);
                    while(!(std::stoi(input))){

                        std::cout << "Needs to be integer.";
                        std::getline(std::cin, input);

                    }
                    root[current_object]["height"] = std::stoi(input);


                } else if(input == "image_path"){

                    std::cout << "Enter new image path: ";
                    std::getline(std::cin, input);
                    root[current_object]["image_path"] = input;    

                } else if(input == "default_propability"){

                    std::cout << "Enter new new default_propability: ";
                    std::getline(std::cin, input);
                    while(!(std::stoi(input))){

                        std::cout << "Needs to be integer.";
                        std::getline(std::cin, input);

                    }
                    root[current_object]["default_propability"] = std::stoi(input);

                } else if(input == "propabillity_tags"){
                    static Json::Value new_tag;
                    std::cout << "add or remove a propability_tag? [a|r]";
                    std::getline(std::cin, input);

                    while(input != "a" && input != "r"){

                        std::cout << "chose to remove or add a propability_tag using either a for adding or r for removing ";
                        std::getline(std::cin, input);

                    }

                    if(input == "a"){

                        std::cout << "Name of propability tag: ";
                        std::getline(std::cin, input);
                        new_tag["name"] = input;

                        std::cout << "Value of propability tag: ";
                        std::getline(std::cin, input);

                        while(!(std::stoi(input))){

                            std::cout << "Needs to be integer.";
                            std::getline(std::cin, input);

                        }
                        
                        new_tag["propability"] = std::stoi(input);

                        root[current_object]["propability_tags"].append(new_tag);


                    } else if(input == "r") {

                        std::cout << "Name of tile to be removed:\n";
                        std::getline(std::cin, input);

                        for(int i = 0; i < root[current_object]["propability_tags"].size(); i++){

                            

                        }

                    }


                } else if(input == "north"){

                    for(int i = 0; i < root[current_object]["width"].size(); i++){


                        std::cout << "state of north node " << i << " of " << root[current_object]["width"].size() << ": ";
                        std::getline(std::cin, input);

                        if(!(input == "0" || input == "1")){

                            std::cout << "Needs to be boolean. Either 1 or 0";
                            i--;
                            continue;
                        }

                        root[current_object]["north"][i] = std::stoi(input);

                    }

                } else if(input == "east"){

                    for(int i = 0; i < root[current_object]["height"].size(); i++){

                        std::cout << "state east node " << i << " of " << root[current_object]["height"].size() << ": ";
                        std::getline(std::cin, input);

                        if(!(input == "0" || input == "1")){

                            std::cout << "Needs to be boolean. Either 1 or 0";
                            i--;
                            continue;
                        }

                        root[current_object]["east"][i] = std::stoi(input);                        


                    }

                } else if(input == "south"){

                    for(int i = 0; i < root[current_object]["width"].size(); i++){

                        std::cout << "state south node " << i << " of " << root[current_object]["width"].size() << ": ";
                        std::getline(std::cin, input);

                        if(!(input == "0" || input == "1")){

                            std::cout << "Needs to be boolean. Either 1 or 0";
                            i--;
                            continue;
                        }

                        root[current_object]["south"][i] = std::stoi(input);

                    }

                } else if(input == "west"){

                    for(int i = 0; i < root[current_object]["height"].size(); i++){

                        std::cout << "state west node " << i << " of " << root[current_object]["height"].size() << ": ";
                        std::getline(std::cin, input);

                        if(!(input == "0" || input == "1")){

                            std::cout << "Needs to be boolean. Either 1 or 0";
                            i--;
                            continue;
                        }

                        root[current_object]["west"][i] = std::stoi(input);
                        
                    }

                }
            
            } else if(input == "type_info") {
                std::cout << "----------------------------------------\n";
                std::cout << "Enter name of type: ";
                std::getline(std::cin, input);

                for(int i = 0; i < root.size(); i++) {
                    if(root[i]["type_name"].asString() == input) {
                        std::cout << "Type found.\n";
                        std::cout << "name: " << root[i]["type_name"] << "\n";
                        std::cout << "tags:";
                        for(int j = 0; j < root[i]["tags"].size(); j++){

                            std::cout << root[i]["tags"][j] << " ";

                        }
                        
                        std::cout << "\nWidth:" << root[i]["width"].asInt() << ", height:" << root[i]["height"].asInt() << "\n";

                        std::cout << "image_path:" << root[i]["image_path"].asString() << "\n";

                        std::cout <<  "default_propability:" << root[i]["default_propability"].asInt() << "\n";

                        std::cout << "Propability_tags:\n";

                        for(int j = 0; j < root[i]["propability_tags"].size();j++){

                            std::cout << "tag:" << root[i]["propability_tags"][j]["tag"].asString() << ", propability:" << root[i]["propability_tags"][j]["propability"].asInt() << "\n";

                        }

                        std::cout << "Propabillity specifiers:\n";

                        for(int j = 0; j < tile_types.size();j++){

                            std::cout << "index:" << tile_types[i].propability_specifiers[j].index << ", propability:" << tile_types[i].propability_specifiers[j].propability << "\n";

                        }

                    }

                }

            } else if(input == "type_list"){
                std::cout << "----------------------------------------\n";
                for(int i = 0; i < root.size(); i++){

                    std::cout << root[i]["type_name"].asString() << "\n";

                }

            } else if(input == "save_changes"){
                
                file.open(file_path, std::ios_base::out | std::ios_base::trunc);
                file << root;
                file.close();
                std::cout << "Changes applied";

            }

        }
        std::cout << "----------------------------------------\n";
        std::cout << "Confirm changes?(type y or dont i dont care)\n";
        std::cin >> input;
        
        if(input == "y"){
            file.open(file_path, std::ios_base::out | std::ios_base::trunc);
            file << root;
            file.close();

            std::cout << "Changes applied.\n";
        } else {

            std::cout << "ok bye then.\n";

        }

        

    }

    //-------------------------------------------------------------------------------------------------------------
    //tile type modifications:

    //adds a tile type and defines its specified propability according to the propability list.
    void add_tile_type(std::string type_name_p, std::vector<std::string> tags,int width_p, int height_p, std::string image_path, float propability_default_p, std::vector<propability_tag> propability_tags, std::vector<bool> north_p, std::vector<bool> east_p, std::vector<bool> south_p, std::vector<bool>west_p){

        sum_propability_default += propability_default_p; // sum of all default propability values
        tile_types.push_back({type_name_p, tags, width_p, height_p, image_path, propability_default_p, {}, propability_tags, north_p, east_p, south_p, west_p});
        evaluate_propability_specifiers();
        //for all tile types,
        for(int i = 0; i < tile_types.size();i++){

            tile_types[i].sum_propability_specific = 0; //reset all sum_propability_specific values to zero, so they can be reconfigured.

            //and for each type relative to each other type
            for(int i_specific = 0; i_specific < tile_types.size(); i_specific++){

                tile_types[i].sum_propability_specific += get_specified_propability(i_specific, i); // set sum_propability_specific to be the sum of all specified propabillities for that type.

            }

        }

        

    }

    //*hold your breath* removes a tile type...(doesnt work right now as im too lazy to fix it)
    void remove_tile_type(std::string type_name_p){

        for(int i = 0; i < tile_types.size(); i++){

            if(tile_types[i].type_name == type_name_p){

                tile_types.erase(tile_types.begin() + i);

            }

        }

        evaluate_propability_specifiers();

    }

    void evaluate_propability_specifiers(){

        //iterate over all tile_types
        for(int current = 0; current < tile_types.size(); current++){
            //for each tile type, iterate over all its tags
            //std::cout << "current " << current << "\n";

            for(int current_tag = 0; current_tag < tile_types[current].propability_tags.size(); current_tag++){
                //std::cout << "current tag " << current_tag << "\n";

                //for each tag of current tile type iterate over all other tile types
                for(int target = 0; target < tile_types.size(); target++){
                    //std::cout << "target " << target << "\n";

                    //for all other tile types, iterate over their different tags
                    for(int target_tag = 0; target_tag < tile_types[target].tags.size(); target_tag++){
                        //std::cout << "target tag " << target_tag << "\n";
                        //for all tags of all other tile types, check if they match the currewt tag
                        if(tile_types[current].propability_tags[current_tag].tag == tile_types[target].tags[target_tag]){
                            //std::cout << "Match found. not in real life but still\n";
                            //if any other tag matches add its id and the propability of its tag to the current objects propability specifiers.
                            tile_types[current].propability_specifiers.push_back({target, tile_types[current].propability_tags[current_tag].propability});


                        }

                    }

                }

            }

        }

        //adjust the sum of the tiles specific propability 
        for(int i = 0; i < tile_types.size();i++){

            tile_types[i].sum_propability_specific = 0; //reset all sum_propability_specific values to zero, so they can be reconfigured.

            //and for each type relative to each other type
            for(int i_specific = 0; i_specific < tile_types.size(); i_specific++){

                tile_types[i].sum_propability_specific += get_specified_propability(i_specific, i); // set sum_propability_specific to be the sum of all specified propabillities for that type.

            }

        }

    }

    //-------------------------------------------------------------------------------------------------------------
    //tile image modifications:
    
    //LEGACY CODE. renders the maze to the maze.img var. Only supports single tiled fields 
    void render_maze(){

        Image temp;

        std::cout << "rendering...\n";

        for(int i_y = 0; i_y < tile_map_height; i_y++){

            for(int i_x = 0; i_x < tile_map_width; i_x++){

                if(tile_map[i_y][i_x].tile_type_id != -1 && tile_map[i_y][i_x].tile_fraction_x == 0 && tile_map[i_y][i_x].tile_fraction_y == 0){

                    temp = ImageCopy(tile_types[tile_map[i_y][i_x].tile_type_id].type_image);

                    if(tile_map[i_y][i_x].direction == 0){

                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    } else if(tile_map[i_y][i_x].direction == 1){

                        ImageRotateCW(&temp);
                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    } if(tile_map[i_y][i_x].direction == 2){

                        ImageRotateCW(&temp);
                        ImageRotateCW(&temp);
                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    }if(tile_map[i_y][i_x].direction == 3){

                        ImageRotateCCW(&temp);
                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    }

                }
            
            }

        }

    }

    //renders the maze to the maze.img yet with a lot of debug info
    void render_maze_debug(){

        Image temp;

        std::cout << "\ntypes:\n";

        for(int i = 0; i < tile_types.size(); i++){

            std::cout << tile_types[i].type_name << ",n:";
            std::cout << "north: ";
            for(int id = 0; id < tile_types[i].width; id++){

                std::cout << tile_types[i].north[id];

            }

            std::cout << "\n";

            std::cout << "east: ";
            for(int id = 0; id < tile_types[i].width; id++){

                std::cout << tile_types[i].east[id];

            }

            std::cout << "\n";

            std::cout << "south: ";
            for(int id = 0; id < tile_types[i].width; id++){

                std::cout << tile_types[i].south[id];

            }

            std::cout << "\n";

            std::cout << "west: ";
            for(int id = 0; id < tile_types[i].width; id++){

                std::cout << tile_types[i].west[id];

            }

            std::cout << "\n";

        }

        std::cout << "rendering...\n";

        std::cout << "__________________________________________________________________\n";

        for(int i_y = 0; i_y < tile_map_height; i_y++){

            for(int i_x = 0; i_x < tile_map_width; i_x++){

                if(tile_map[i_y][i_x].tile_type_id != -1){

                    /*std::cout << tile_map[i_y][i_x].tile_type_id << tile_map[i_y][i_x].direction
                    << ",n:" << is_side_open(0, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id)
                    << ",e:" << is_side_open(1, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id)
                    << ",s:" << is_side_open(2, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id)
                    << ",w:" << is_side_open(3, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id) << "\n";*/

                    temp = ImageCopy(tile_types[tile_map[i_y][i_x].tile_type_id].type_image);

                    if(i_y - 1 >= 0 && tile_map[i_y - 1][i_x].tile_type_id == -1 && is_side_open(0, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id, tile_map[i_y][i_x].tile_fraction_y)){

                        ImageDrawRectangle(&maze_img, i_x * tile_width + tile_width / 4, i_y * tile_height - tile_height / 2, tile_width / 2, tile_height / 2, BLUE);
                        
                        

                    }

                    if(i_x + 1 < tile_map_width && tile_map[i_y][i_x + 1].tile_type_id == -1 && is_side_open(1, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id, tile_map[i_y][i_x].tile_fraction_x)){

                        ImageDrawRectangle(&maze_img, i_x * tile_width + tile_width, i_y * tile_height + tile_height / 4, tile_width / 2, tile_height / 2, GREEN);
                        
                    }

                    if(i_y + 1 < tile_map_height && tile_map[i_y + 1][i_x].tile_type_id == -1 && is_side_open(2, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id, tile_map[i_y][i_x].tile_fraction_y)){

                        ImageDrawRectangle(&maze_img, i_x * tile_width + tile_width / 4, i_y * tile_height + tile_height, tile_width / 2, tile_height / 2, RED);

                    }

                    if(i_x - 1 >= 0 && tile_map[i_y][i_x - 1].tile_type_id == -1 && is_side_open(3, tile_map[i_y][i_x].direction, tile_map[i_y][i_x].tile_type_id, tile_map[i_y][i_x].tile_fraction_x)){

                        ImageDrawRectangle(&maze_img, i_x * tile_width - tile_width / 2, i_y * tile_height + tile_height / 4, tile_width / 2, tile_height / 2, YELLOW);

                    }

                    if(tile_map[i_y][i_x].direction == 0){

                        ImageColorTint(&temp, BLUE);

                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    } else if(tile_map[i_y][i_x].direction == 1){

                        ImageColorTint(&temp, GREEN);

                        ImageRotateCW(&temp);
                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    } if(tile_map[i_y][i_x].direction == 2){

                        ImageColorTint(&temp, RED);

                        ImageRotateCW(&temp);
                        ImageRotateCW(&temp);
                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    }if(tile_map[i_y][i_x].direction == 3){

                        ImageColorTint(&temp, YELLOW);

                        ImageRotateCCW(&temp);
                        ImageDrawImage(maze_img, temp, i_x * tile_width, i_y * tile_height);

                    }

                }
            
            }

        }

    }

    //prints all info of said tile
    void debug_print_tile(Vector2 position){

        std::cout << "x:" << position.x << ",y:" << position.y << ",type:" << tile_map[position.y][position.x].tile_type_id << ",direction:" << tile_map[position.y][position.x].direction << "\n";

    }
    
    //prints the whole tilemap contents to the console(spammmmmm)
    void debug_print_tile_map(){

        for(int i_y = 0; i_y < tile_map_height; i_y++){

            for(int i_x = 0; i_x < tile_map_width; i_x++){

                std::cout << "|x:"<< i_x << ",y:" << i_y << ",type:" << tile_map[i_y][i_x].tile_type_id << ",dir" << tile_map[i_y][i_x].direction << "|\t";

            }

            std::cout << "\n\n";

        }

    }

    void debug_print_tile_type(int index){
        std::cout << "-------------------------------------------------------------------------------------\n";        
        std::cout << "Debug info: Tile " << index << ".\n";
        std::cout << "Tile width: " << tile_types[index].width << ", tile height: " <<  tile_types[index].height << ".\n";
        std::cout << "Image path: " << tile_types[index].image_path << ".\n";
        std::cout << "image Data. Format: " << tile_types[index].type_image.format << ", img width: " << tile_types[index].type_image.width << ", img height: " << tile_types[index].type_image.height << ".\n";
        std::cout << "Default propability: " << tile_types[index].default_propability << ".\n";
        std::cout << "Propabillity specifiers:\n";
        for(int i = 0; i < tile_types[index].propability_specifiers.size(); i++){

            std::cout << tile_types[index].propability_specifiers[i].index << ": " << tile_types[tile_types[index].propability_specifiers[i].index].type_name << ": " << tile_types[index].propability_specifiers[i].propability << ". ";


        }

        std::cout << "\nnorth: ";
        for(int i = 0; i < tile_types[index].north.size(); i++){

            std::cout << tile_types[index].north[i] << ", ";
        }

        std::cout << "east: ";
        for(int i = 0; i < tile_types[index].east.size(); i++){

            std::cout << tile_types[index].east[i] << ", ";
        }

        std::cout << "south: ";
        for(int i = 0; i < tile_types[index].south.size(); i++){

            std::cout << tile_types[index].south[i] << ", ";

        }

        std::cout << "west: ";
        for(int i = 0; i < tile_types[index].west.size(); i++){

            std::cout << tile_types[index].west[i] << ", ";
        }
        std::cout << "\n";
        

    }

    void debug_print_tile_types(){

        for(int i = 0; i < tile_types.size(); i++){

            debug_print_tile_type(i);

        }

    }

    //export maze as png file in export directory
    void safe_maze(std::string name){

        static std::string name_temp;
        static std::time_t currentTime; 
        static std::string current_time;
        
        currentTime = std::time(nullptr);
        
        current_time = std::asctime(std::localtime(&currentTime));
        current_time.pop_back();
        name_temp = "export/" + current_time + "," + name;
        

        ExportImage(maze_img, name_temp.c_str());

    }


    void save_tile_types(std::string file_path){

        std::ofstream file_out(file_path.c_str(), std::ios_base::out);
        Json::Value root;

        for(int i = 0; i < tile_types.size(); i++){

            root[i] = tile_types[i].get_json();

        }

        file_out << root;
        std::cout << "Successfully saved to file\n";


    }

    void load_tile_types(std::string new_file_path){
        
        

        std::ifstream file_in(new_file_path.c_str(), std::ios_base::in);

        if(!FileExists(new_file_path.c_str())){

            std::cout << "file doesnt exist.\n";

        }

        if(!file_in.is_open()){

            std::cout << "There is no file: " << new_file_path << ".\n";
            return;

        } 
        
        
        file_in >> root;

        file_in.close();
        file_path = new_file_path;

        tile_types.resize(root.size());
        
        for(int i = 0; i < root.size(); i++){
            
            std::cout << "\nObject at index " << i << ";" << "\n";
            tile_types[i].load_from_json(root[i]);
        }

        evaluate_propability_specifiers();
        

        std::cout << "Sucessfully loaded tile types :3\n";

    }

};